import { useState, useEffect } from 'react';

export type Language = 'en' | 'ja' | 'ko' | 'zh';

export const SUPPORTED_LANGUAGES = {
  en: 'English',
  ja: '日本語',
  ko: '한국어', 
  zh: '中文'
} as const;

export const translations = {
  en: {
    // Header
    'services': 'Services',
    'talent': 'Talent Pool',
    'success': 'Success Stories',
    'contact': 'Contact',
    'getStarted': 'Get Started',
    'dashboard': 'Dashboard',
    'clientPortal': 'Client Portal',
    
    // Hero Section
    'hero.badge': 'Tech Companies Trust Us',
    'hero.title1': 'Scale Fast with',
    'hero.title2': 'Elite Indian Engineers',
    'hero.subtitle': '60% cost reduction. 48-hour deployment. Pre-vetted talent.',
    'hero.description': 'Transform your tech projects with our proven engineering expertise.',
    'hero.startHiring': 'Start Hiring Now',
    'hero.seeHow': 'See How It Works',
    'hero.globalReach': 'Global Reach',
    'hero.techExcellence': 'Tech Excellence',
    'hero.rapidDeployment': 'Rapid Deployment',
    'hero.liveTalent': 'Live Talent Dashboard',
    'hero.realTimeAccess': 'Real-time access to our engineering network',
    'hero.availableNow': 'Available Now',
    'hero.liveEngineers': 'Live: 847 engineers online and ready',
    
    // Problem-Solution
    'problem.title': 'The Challenge Asian Companies Face',
    'problem.description': 'Growing tech companies in Asia struggle with talent shortages, high costs, and lengthy hiring processes that slow down innovation.',
    'problem.talentShortage': 'Talent Shortage',
    'problem.talentDesc': 'Limited pool of qualified engineers in local markets, making it difficult to find the right skills for complex projects.',
    'problem.highCosts': 'High Costs',
    'problem.costsDesc': 'Expensive local talent and recruitment fees that strain budgets, especially for startups and growing companies.',
    'problem.slowHiring': 'Slow Hiring',
    'problem.hiringDesc': 'Lengthy recruitment processes that delay project timelines and miss critical market opportunities.',
    'solution.badge': 'Tech Japan Solution',
    'solution.title1': 'Transform Your Business with',
    'solution.title2': 'Instant Engineering Access',
    'solution.subtitle': 'Cut costs by 60%. Start in 48 hours. Scale without limits.',
    'solution.description': 'Our vetted Indian engineers integrate seamlessly with Asian companies, delivering world-class results at a fraction of traditional costs.',
    
    // Contact
    'contact.badge': 'Start Your Project Today',
    'contact.title1': 'Ready to Build Something Amazing?',
    'contact.title2': 'Let\'s Connect You with Top Talent',
    'contact.subtitle': '48-hour matching. Zero risk. Immediate impact.',
    'contact.description': 'Tell us about your project and we\'ll match you with the perfect engineers from our vetted talent pool. Start building your dream team today.',
    'contact.freeConsultation': 'Free Consultation',
    'contact.responseTime': '48-Hour Response',
    'contact.preverified': 'Pre-Vetted Talent',
    'contact.form.title': 'Start Your Project',
    'contact.form.subtitle': 'Get matched in 48 hours',
    'contact.form.companyName': 'Company Name',
    'contact.form.firstName': 'First Name',
    'contact.form.lastName': 'Last Name',
    'contact.form.email': 'Business Email',
    'contact.form.phone': 'Phone Number',
    'contact.form.engineerType': 'What type of engineers do you need?',
    'contact.form.projectDetails': 'Project Details',
    'contact.form.submit': 'Get Matched with Engineers Now',
    'contact.form.submitting': 'Please wait...',
    'contact.form.terms': 'By submitting this form, you agree to our Terms of Service and Privacy Policy. We\'ll connect you with qualified engineers within 48 hours.',
    
    // Common
    'common.required': 'Required',
    'common.optional': 'Optional'
  },
  ja: {
    // Header
    'services': 'サービス',
    'talent': 'タレントプール',
    'success': '成功事例',
    'contact': 'お問い合わせ',
    'getStarted': '始める',
    'dashboard': 'ダッシュボード',
    'clientPortal': 'クライアントポータル',
    
    // Hero Section
    'hero.badge': '技術企業が信頼',
    'hero.title1': '迅速にスケールする',
    'hero.title2': 'エリートインドエンジニア',
    'hero.subtitle': '60%コスト削減。48時間デプロイ。事前審査済み人材。',
    'hero.description': '実証済みのエンジニアリング専門知識でテクノロジープロジェクトを変革。',
    'hero.startHiring': '今すぐ採用開始',
    'hero.seeHow': '仕組みを見る',
    'hero.globalReach': 'グローバルリーチ',
    'hero.techExcellence': 'テクノロジー卓越性',
    'hero.rapidDeployment': '迅速デプロイ',
    'hero.liveTalent': 'ライブタレントダッシュボード',
    'hero.realTimeAccess': 'エンジニアリングネットワークへのリアルタイムアクセス',
    'hero.availableNow': '今すぐ利用可能',
    'hero.liveEngineers': 'ライブ：847名のエンジニアがオンラインで待機',
    
    // Problem-Solution
    'problem.title': 'アジア企業が直面する課題',
    'problem.description': 'アジアの成長するテック企業は、人材不足、高コスト、長期の採用プロセスによりイノベーションが遅れています。',
    'problem.talentShortage': '人材不足',
    'problem.talentDesc': '地域市場での有資格エンジニアの限られたプールで、複雑なプロジェクトに適したスキルを見つけることが困難。',
    'problem.highCosts': '高コスト',
    'problem.costsDesc': '特にスタートアップや成長企業の予算を圧迫する高額な地域人材と採用費用。',
    'problem.slowHiring': '遅い採用',
    'problem.hiringDesc': 'プロジェクトタイムラインを遅らせ、重要な市場機会を逃す長期採用プロセス。',
    'solution.badge': 'Tech Japan ソリューション',
    'solution.title1': 'ビジネスを変革する',
    'solution.title2': 'インスタントエンジニアリングアクセス',
    'solution.subtitle': '60%コスト削減。48時間で開始。無制限スケール。',
    'solution.description': '審査済みインドエンジニアがアジア企業とシームレスに統合し、従来コストの一部で世界クラスの結果を提供。',
    
    // Contact
    'contact.badge': '今日プロジェクトを開始',
    'contact.title1': '素晴らしいものを構築する準備はできていますか？',
    'contact.title2': 'トップタレントとつながりましょう',
    'contact.subtitle': '48時間マッチング。リスクゼロ。即座のインパクト。',
    'contact.description': 'プロジェクトについて教えてください。審査済みタレントプールから完璧なエンジニアをマッチングします。今日からドリームチームの構築を始めましょう。',
    'contact.freeConsultation': '無料相談',
    'contact.responseTime': '48時間対応',
    'contact.preverified': '事前審査済み人材',
    'contact.form.title': 'プロジェクトを開始',
    'contact.form.subtitle': '48時間でマッチング',
    'contact.form.companyName': '会社名',
    'contact.form.firstName': '名',
    'contact.form.lastName': '姓',
    'contact.form.email': 'ビジネスメール',
    'contact.form.phone': '電話番号',
    'contact.form.engineerType': 'どのタイプのエンジニアが必要ですか？',
    'contact.form.projectDetails': 'プロジェクト詳細',
    'contact.form.submit': '今すぐエンジニアとマッチング',
    'contact.form.submitting': 'お待ちください...',
    'contact.form.terms': 'このフォームを送信することで、利用規約とプライバシーポリシーに同意します。48時間以内に資格のあるエンジニアとつなぎます。',
    
    // Common
    'common.required': '必須',
    'common.optional': 'オプション'
  },
  ko: {
    // Header  
    'services': '서비스',
    'talent': '인재풀',
    'success': '성공사례',
    'contact': '연락처',
    'getStarted': '시작하기',
    'dashboard': '대시보드',
    'clientPortal': '클라이언트 포털',
    
    // Hero Section
    'hero.badge': '기술 기업이 신뢰',
    'hero.title1': '빠르게 확장하는',
    'hero.title2': '엘리트 인도 엔지니어',
    'hero.subtitle': '60% 비용 절감. 48시간 배포. 사전 검증된 인재.',
    'hero.description': '검증된 엔지니어링 전문 지식으로 기술 프로젝트를 혁신하세요.',
    'hero.startHiring': '지금 채용 시작',
    'hero.seeHow': '작동 방식 보기',
    'hero.globalReach': '글로벌 도달',
    'hero.techExcellence': '기술 우수성',
    'hero.rapidDeployment': '신속 배포',
    'hero.liveTalent': '라이브 인재 대시보드',
    'hero.realTimeAccess': '엔지니어링 네트워크에 대한 실시간 액세스',
    'hero.availableNow': '지금 이용 가능',
    'hero.liveEngineers': '라이브: 847명의 엔지니어가 온라인에서 대기 중',
    
    // Problem-Solution
    'problem.title': '아시아 기업이 직면한 도전',
    'problem.description': '아시아의 성장하는 기술 기업들은 인재 부족, 높은 비용, 긴 채용 프로세스로 인해 혁신이 느려지고 있습니다.',
    'problem.talentShortage': '인재 부족',
    'problem.talentDesc': '지역 시장의 제한된 자격있는 엔지니어 풀로 복잡한 프로젝트에 적합한 기술을 찾기 어려움.',
    'problem.highCosts': '높은 비용',
    'problem.costsDesc': '특히 스타트업과 성장 기업의 예산을 압박하는 비싼 지역 인재와 채용 수수료.',
    'problem.slowHiring': '느린 채용',
    'problem.hiringDesc': '프로젝트 일정을 지연시키고 중요한 시장 기회를 놓치는 긴 채용 프로세스.',
    'solution.badge': 'Tech Japan 솔루션',
    'solution.title1': '비즈니스를 혁신하는',
    'solution.title2': '즉시 엔지니어링 액세스',
    'solution.subtitle': '60% 비용 절감. 48시간 시작. 무제한 확장.',
    'solution.description': '검증된 인도 엔지니어가 아시아 기업과 원활하게 통합되어 기존 비용의 일부로 세계 수준의 결과를 제공합니다.',
    
    // Contact
    'contact.badge': '오늘 프로젝트 시작',
    'contact.title1': '놀라운 것을 구축할 준비가 되셨나요?',
    'contact.title2': '최고 인재와 연결해드립니다',
    'contact.subtitle': '48시간 매칭. 위험 제로. 즉시 영향.',
    'contact.description': '프로젝트에 대해 알려주시면 검증된 인재 풀에서 완벽한 엔지니어를 매칭해드립니다. 오늘부터 드림팀 구축을 시작하세요.',
    'contact.freeConsultation': '무료 상담',
    'contact.responseTime': '48시간 응답',
    'contact.preverified': '사전 검증된 인재',
    'contact.form.title': '프로젝트 시작',
    'contact.form.subtitle': '48시간 매칭',
    'contact.form.companyName': '회사명',
    'contact.form.firstName': '이름',
    'contact.form.lastName': '성',
    'contact.form.email': '비즈니스 이메일',
    'contact.form.phone': '전화번호',
    'contact.form.engineerType': '어떤 유형의 엔지니어가 필요하신가요?',
    'contact.form.projectDetails': '프로젝트 세부사항',
    'contact.form.submit': '지금 엔지니어와 매칭',
    'contact.form.submitting': '잠시만 기다려주세요...',
    'contact.form.terms': '이 양식을 제출함으로써 서비스 약관 및 개인정보 보호정책에 동의합니다. 48시간 이내에 자격있는 엔지니어와 연결해드립니다.',
    
    // Common
    'common.required': '필수',
    'common.optional': '선택'
  },
  zh: {
    // Header
    'services': '服务',
    'talent': '人才库',
    'success': '成功案例',
    'contact': '联系我们',
    'getStarted': '开始',
    'dashboard': '仪表板',
    'clientPortal': '客户门户',
    
    // Hero Section
    'hero.badge': '技术公司信赖',
    'hero.title1': '快速扩展',
    'hero.title2': '精英印度工程师',
    'hero.subtitle': '60%成本降低。48小时部署。预审人才。',
    'hero.description': '用我们验证的工程专业知识改变您的技术项目。',
    'hero.startHiring': '立即开始招聘',
    'hero.seeHow': '查看工作原理',
    'hero.globalReach': '全球覆盖',
    'hero.techExcellence': '技术卓越',
    'hero.rapidDeployment': '快速部署',
    'hero.liveTalent': '实时人才仪表板',
    'hero.realTimeAccess': '实时访问我们的工程网络',
    'hero.availableNow': '现在可用',
    'hero.liveEngineers': '实时：847名工程师在线待命',
    
    // Problem-Solution
    'problem.title': '亚洲公司面临的挑战',
    'problem.description': '亚洲增长的技术公司在人才短缺、高成本和冗长的招聘流程中挣扎，这些都减慢了创新速度。',
    'problem.talentShortage': '人才短缺',
    'problem.talentDesc': '当地市场的合格工程师池有限，很难找到复杂项目所需的合适技能。',
    'problem.highCosts': '高成本',
    'problem.costsDesc': '昂贵的本地人才和招聘费用给预算带来压力，特别是对初创公司和成长型公司。',
    'problem.slowHiring': '招聘缓慢',
    'problem.hiringDesc': '冗长的招聘流程延误项目时间表，错失关键市场机会。',
    'solution.badge': 'Tech Japan 解决方案',
    'solution.title1': '用以下方式改变您的业务',
    'solution.title2': '即时工程访问',
    'solution.subtitle': '降低60%成本。48小时开始。无限扩展。',
    'solution.description': '我们经过审查的印度工程师与亚洲公司无缝集成，以传统成本的一小部分提供世界级结果。',
    
    // Contact
    'contact.badge': '今天开始您的项目',
    'contact.title1': '准备好构建令人惊叹的东西了吗？',
    'contact.title2': '让我们为您连接顶级人才',
    'contact.subtitle': '48小时匹配。零风险。立即影响。',
    'contact.description': '告诉我们您的项目，我们将从经过审查的人才库中为您匹配完美的工程师。今天开始构建您的梦想团队。',
    'contact.freeConsultation': '免费咨询',
    'contact.responseTime': '48小时回复',
    'contact.preverified': '预审人才',
    'contact.form.title': '开始您的项目',
    'contact.form.subtitle': '48小时匹配',
    'contact.form.companyName': '公司名称',
    'contact.form.firstName': '名',
    'contact.form.lastName': '姓',
    'contact.form.email': '商务邮箱',
    'contact.form.phone': '电话号码',
    'contact.form.engineerType': '您需要什么类型的工程师？',
    'contact.form.projectDetails': '项目详情',
    'contact.form.submit': '立即与工程师匹配',
    'contact.form.submitting': '请稍候...',
    'contact.form.terms': '提交此表格即表示您同意我们的服务条款和隐私政策。我们将在48小时内为您连接合格的工程师。',
    
    // Common
    'common.required': '必填',
    'common.optional': '可选'
  }
};

export function useLanguage() {
  const [language, setLanguage] = useState<Language>(() => {
    if (typeof window !== 'undefined') {
      const stored = localStorage.getItem('preferred-language') as Language;
      if (stored && Object.keys(SUPPORTED_LANGUAGES).includes(stored)) {
        return stored;
      }
      // Auto-detect from browser
      const browserLang = navigator.language.toLowerCase();
      if (browserLang.startsWith('ja')) return 'ja';
      if (browserLang.startsWith('ko')) return 'ko';
      if (browserLang.startsWith('zh')) return 'zh';
    }
    return 'en';
  });

  const changeLanguage = (newLanguage: Language) => {
    setLanguage(newLanguage);
    if (typeof window !== 'undefined') {
      localStorage.setItem('preferred-language', newLanguage);
    }
  };

  const t = (key: string): string => {
    const keys = key.split('.');
    let value: any = translations[language];
    
    for (const k of keys) {
      if (value && typeof value === 'object' && k in value) {
        value = value[k];
      } else {
        // Fallback to English if translation not found
        value = translations.en;
        for (const fallbackKey of keys) {
          if (value && typeof value === 'object' && fallbackKey in value) {
            value = value[fallbackKey];
          } else {
            return key; // Return key if no translation found
          }
        }
        break;
      }
    }
    
    return typeof value === 'string' ? value : key;
  };

  return { language, changeLanguage, t };
}