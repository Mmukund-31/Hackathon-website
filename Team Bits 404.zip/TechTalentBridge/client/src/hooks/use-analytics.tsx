import { useEffect, useRef } from 'react';
import { useLocation } from 'wouter';
import { apiRequest } from '@/lib/queryClient';

// Generate a simple session ID
function generateSessionId(): string {
  return Math.random().toString(36).substring(2, 15) + Math.random().toString(36).substring(2, 15);
}

// Get or create session ID
function getSessionId(): string {
  let sessionId = sessionStorage.getItem('analytics_session_id');
  if (!sessionId) {
    sessionId = generateSessionId();
    sessionStorage.setItem('analytics_session_id', sessionId);
  }
  return sessionId;
}

export const useAnalytics = () => {
  const [location] = useLocation();
  const prevLocationRef = useRef<string>(location);
  
  useEffect(() => {
    if (location !== prevLocationRef.current) {
      trackPageView(location);
      prevLocationRef.current = location;
    }
  }, [location]);
};

export const trackPageView = async (path: string) => {
  try {
    await apiRequest('POST', '/api/analytics/pageview', {
      sessionId: getSessionId(),
      path,
      referrer: document.referrer || null,
      userAgent: navigator.userAgent,
      language: navigator.language
    });
  } catch (error) {
    // Silently fail for analytics
    console.debug('Analytics tracking failed:', error);
  }
};

export const trackEvent = async (eventType: string, eventData?: any) => {
  try {
    await apiRequest('POST', '/api/analytics/event', {
      sessionId: getSessionId(),
      eventType,
      eventData
    });
  } catch (error) {
    // Silently fail for analytics
    console.debug('Event tracking failed:', error);
  }
};