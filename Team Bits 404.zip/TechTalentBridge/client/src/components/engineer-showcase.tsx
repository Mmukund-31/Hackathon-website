import { useState } from 'react';
import { Card, CardContent, CardHeader } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { Star, MapPin, Clock, Code, Award, ChevronLeft, ChevronRight } from 'lucide-react';
import { useLanguage } from '@/lib/i18n';

interface Engineer {
  id: number;
  name: string;
  title: string;
  experience: number;
  rating: number;
  hourlyRate: number;
  location: string;
  availability: string;
  skills: string[];
  projectsCompleted: number;
  languages: string[];
  avatar: string;
  specialization: string;
  certifications: string[];
}

// Real engineer data structure (would come from API)
const engineers: Engineer[] = [
  {
    id: 1,
    name: "Rajesh Kumar",
    title: "Full Stack Developer",
    experience: 6,
    rating: 4.9,
    hourlyRate: 45,
    location: "Bangalore, India",
    availability: "Available Now",
    skills: ["React", "Node.js", "TypeScript", "AWS", "MongoDB"],
    projectsCompleted: 127,
    languages: ["English", "Hindi", "Japanese"],
    avatar: "/api/placeholder/150/150",
    specialization: "E-commerce & Fintech",
    certifications: ["AWS Certified", "Google Cloud Professional"]
  },
  {
    id: 2,
    name: "Priya Sharma",
    title: "AI/ML Engineer",
    experience: 5,
    rating: 4.8,
    hourlyRate: 55,
    location: "Hyderabad, India",
    availability: "Available Now",
    skills: ["Python", "TensorFlow", "PyTorch", "Docker", "Kubernetes"],
    projectsCompleted: 89,
    languages: ["English", "Hindi", "Korean"],
    avatar: "/api/placeholder/150/150",
    specialization: "Computer Vision & NLP",
    certifications: ["TensorFlow Certified", "Azure AI Engineer"]
  },
  {
    id: 3,
    name: "Arjun Patel",
    title: "Mobile App Developer",
    experience: 4,
    rating: 4.7,
    hourlyRate: 40,
    location: "Pune, India",
    availability: "Available in 2 weeks",
    skills: ["React Native", "Flutter", "iOS", "Android", "Firebase"],
    projectsCompleted: 156,
    languages: ["English", "Hindi", "Gujarati"],
    avatar: "/api/placeholder/150/150",
    specialization: "Cross-platform Mobile Apps",
    certifications: ["Google Associate Android Developer"]
  }
];

export default function EngineerShowcase() {
  const [currentIndex, setCurrentIndex] = useState(0);
  const { t } = useLanguage();

  const nextEngineer = () => {
    setCurrentIndex((prev) => (prev + 1) % engineers.length);
  };

  const prevEngineer = () => {
    setCurrentIndex((prev) => (prev - 1 + engineers.length) % engineers.length);
  };

  const currentEngineer = engineers[currentIndex];

  return (
    <div className="bg-slate-50 py-16" id="engineers">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-12">
          <div className="inline-flex items-center bg-primary/10 text-primary px-4 py-2 rounded-full text-sm font-medium mb-4">
            <Award className="w-4 h-4 mr-2" />
            Live Engineer Showcase
          </div>
          <h2 className="text-4xl font-bold text-slate-900 mb-4">
            Meet Your Next Team Member
          </h2>
          <p className="text-xl text-slate-600 max-w-3xl mx-auto">
            Browse our pre-vetted engineers ready to join your team today
          </p>
        </div>

        <div className="max-w-4xl mx-auto">
          <Card className="border-0 shadow-xl overflow-hidden">
            <div className="bg-gradient-to-r from-primary to-blue-600 p-6 text-white">
              <div className="flex items-center justify-between mb-4">
                <div className="flex items-center space-x-4">
                  <Avatar className="w-16 h-16 border-4 border-white/20">
                    <AvatarImage src={currentEngineer.avatar} alt={currentEngineer.name} />
                    <AvatarFallback className="bg-white/20 text-white text-xl">
                      {currentEngineer.name.split(' ').map(n => n[0]).join('')}
                    </AvatarFallback>
                  </Avatar>
                  <div>
                    <h3 className="text-2xl font-bold">{currentEngineer.name}</h3>
                    <p className="text-blue-100">{currentEngineer.title}</p>
                    <div className="flex items-center mt-1">
                      <div className="flex items-center mr-4">
                        {[...Array(5)].map((_, i) => (
                          <Star
                            key={i}
                            className={`w-4 h-4 ${
                              i < Math.floor(currentEngineer.rating)
                                ? 'text-yellow-300 fill-current'
                                : 'text-white/40'
                            }`}
                          />
                        ))}
                        <span className="ml-1 text-sm">{currentEngineer.rating}</span>
                      </div>
                      <Badge className="bg-green-500 text-white">
                        {currentEngineer.availability}
                      </Badge>
                    </div>
                  </div>
                </div>
                <div className="text-right">
                  <div className="text-3xl font-bold">${currentEngineer.hourlyRate}</div>
                  <div className="text-blue-100 text-sm">per hour</div>
                </div>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-3 gap-4 text-center">
                <div className="bg-white/10 rounded-lg p-3">
                  <div className="text-2xl font-bold">{currentEngineer.experience}</div>
                  <div className="text-blue-100 text-sm">Years Experience</div>
                </div>
                <div className="bg-white/10 rounded-lg p-3">
                  <div className="text-2xl font-bold">{currentEngineer.projectsCompleted}</div>
                  <div className="text-blue-100 text-sm">Projects Completed</div>
                </div>
                <div className="bg-white/10 rounded-lg p-3">
                  <div className="text-2xl font-bold">{currentEngineer.languages.length}</div>
                  <div className="text-blue-100 text-sm">Languages</div>
                </div>
              </div>
            </div>

            <CardContent className="p-6">
              <div className="grid md:grid-cols-2 gap-6">
                <div>
                  <h4 className="font-semibold text-slate-900 mb-3 flex items-center">
                    <Code className="w-4 h-4 mr-2 text-primary" />
                    Technical Skills
                  </h4>
                  <div className="flex flex-wrap gap-2 mb-4">
                    {currentEngineer.skills.map((skill, index) => (
                      <Badge key={index} variant="secondary" className="text-sm">
                        {skill}
                      </Badge>
                    ))}
                  </div>

                  <h4 className="font-semibold text-slate-900 mb-3 flex items-center">
                    <Award className="w-4 h-4 mr-2 text-primary" />
                    Certifications
                  </h4>
                  <div className="space-y-1">
                    {currentEngineer.certifications.map((cert, index) => (
                      <div key={index} className="text-sm text-slate-600 flex items-center">
                        <div className="w-2 h-2 bg-green-500 rounded-full mr-2"></div>
                        {cert}
                      </div>
                    ))}
                  </div>
                </div>

                <div>
                  <h4 className="font-semibold text-slate-900 mb-3 flex items-center">
                    <MapPin className="w-4 h-4 mr-2 text-primary" />
                    Location & Languages
                  </h4>
                  <p className="text-slate-600 mb-2">{currentEngineer.location}</p>
                  <div className="flex flex-wrap gap-1 mb-4">
                    {currentEngineer.languages.map((lang, index) => (
                      <Badge key={index} variant="outline" className="text-xs">
                        {lang}
                      </Badge>
                    ))}
                  </div>

                  <h4 className="font-semibold text-slate-900 mb-3">Specialization</h4>
                  <p className="text-slate-600 mb-4">{currentEngineer.specialization}</p>

                  <div className="flex space-x-3">
                    <Button className="flex-1 bg-primary hover:bg-blue-700">
                      Hire {currentEngineer.name.split(' ')[0]}
                    </Button>
                    <Button variant="outline" className="flex-1">
                      View Portfolio
                    </Button>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Navigation */}
          <div className="flex justify-center items-center mt-6 space-x-4">
            <Button
              variant="outline"
              size="sm"
              onClick={prevEngineer}
              className="p-2"
            >
              <ChevronLeft className="w-4 h-4" />
            </Button>
            
            <div className="flex space-x-2">
              {engineers.map((_, index) => (
                <button
                  key={index}
                  onClick={() => setCurrentIndex(index)}
                  className={`w-3 h-3 rounded-full transition-colors ${
                    index === currentIndex ? 'bg-primary' : 'bg-slate-300'
                  }`}
                />
              ))}
            </div>

            <Button
              variant="outline"
              size="sm"
              onClick={nextEngineer}
              className="p-2"
            >
              <ChevronRight className="w-4 h-4" />
            </Button>
          </div>

          <div className="text-center mt-6">
            <p className="text-slate-600 mb-4">
              {engineers.length} engineers available • Updated in real-time
            </p>
            <Button variant="outline" className="bg-white">
              Browse All Engineers
            </Button>
          </div>
        </div>
      </div>
    </div>
  );
}