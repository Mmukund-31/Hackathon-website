import { Star } from "lucide-react";

export default function SuccessStories() {
  const testimonials = [
    {
      company: "Sakura Tech",
      location: "Tokyo, Japan",
      initial: "S",
      gradient: "from-blue-500 to-purple-600",
      testimonial: "Tech Japan helped us scale our fintech platform 3x faster than expected. The Indian engineers were incredibly skilled and integrated seamlessly with our team.",
      author: "Hiroshi Tanaka",
      role: "CTO"
    },
    {
      company: "KoreaTech Solutions",
      location: "Seoul, South Korea",
      initial: "K",
      gradient: "from-green-500 to-teal-600",
      testimonial: "We reduced our development costs by 55% while maintaining excellent quality. The AI/ML expertise from Indian engineers was exactly what we needed.",
      author: "Min-jun Kim",
      role: "Head of Engineering"
    },
    {
      company: "Singapore Dynamics",
      location: "Singapore",
      initial: "S",
      gradient: "from-orange-500 to-red-600",
      testimonial: "Amazing experience! We went from concept to production in just 8 weeks. The mobile app they built exceeded all our expectations.",
      author: "Priya Mehta",
      role: "Product Director"
    }
  ];

  const stats = [
    { value: "500+", label: "Asian Companies Served" },
    { value: "6,000+", label: "Vetted Engineers" },
    { value: "95%", label: "Client Satisfaction" },
    { value: "48hrs", label: "Average Start Time" }
  ];

  return (
    <section id="success" className="py-20 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="text-3xl lg:text-5xl font-bold text-slate-900 mb-6">
            Success Stories from Asian Leaders
          </h2>
          <p className="text-xl text-slate-600 max-w-3xl mx-auto">
            See how top companies across Asia have accelerated their growth with our talented Indian engineers.
          </p>
        </div>
        
        <div className="grid lg:grid-cols-3 gap-8 mb-16">
          {testimonials.map((testimonial, index) => (
            <div key={index} className="bg-slate-50 p-8 rounded-2xl border border-slate-200">
              <div className="flex items-center mb-6">
                <div className={`w-12 h-12 bg-gradient-to-r ${testimonial.gradient} rounded-full flex items-center justify-center mr-4`}>
                  <span className="text-white font-bold">{testimonial.initial}</span>
                </div>
                <div>
                  <div className="font-bold text-slate-900">{testimonial.company}</div>
                  <div className="text-sm text-slate-500">{testimonial.location}</div>
                </div>
              </div>
              
              <div className="flex mb-4">
                {[...Array(5)].map((_, i) => (
                  <Star key={i} className="w-4 h-4 text-yellow-500 fill-current" />
                ))}
              </div>
              
              <p className="text-slate-700 mb-6">
                "{testimonial.testimonial}"
              </p>
              
              <div className="text-sm text-slate-500">
                <span>{testimonial.author}</span> • <span>{testimonial.role}</span>
              </div>
            </div>
          ))}
        </div>
        
        <div className="bg-gradient-to-r from-primary to-blue-700 rounded-3xl p-12 text-white">
          <div className="grid md:grid-cols-4 gap-8 text-center">
            {stats.map((stat, index) => (
              <div key={index}>
                <div className="text-4xl font-bold mb-2">{stat.value}</div>
                <div className="text-blue-100">{stat.label}</div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}
