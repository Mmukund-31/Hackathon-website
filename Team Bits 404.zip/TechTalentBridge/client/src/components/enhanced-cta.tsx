import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { ArrowRight, Calendar, Phone, MessageCircle, FileText, Clock, Shield } from 'lucide-react';
import { useLanguage } from '@/lib/i18n';

interface CTAProps {
  variant?: 'primary' | 'secondary' | 'urgent' | 'consultation';
  title?: string;
  subtitle?: string;
  showBenefits?: boolean;
  showUrgency?: boolean;
}

export default function EnhancedCTA({ 
  variant = 'primary', 
  title,
  subtitle,
  showBenefits = true,
  showUrgency = false 
}: CTAProps) {
  const { t } = useLanguage();

  const variants = {
    primary: {
      bgColor: 'bg-gradient-to-r from-primary to-blue-600',
      textColor: 'text-white',
      title: title || 'Ready to Scale Your Development?',
      subtitle: subtitle || 'Join 200+ companies who reduced costs by 60% while accelerating delivery',
      primaryCTA: 'Schedule Free Consultation',
      secondaryCTA: 'Request Demo',
      icon: Calendar
    },
    secondary: {
      bgColor: 'bg-slate-50',
      textColor: 'text-slate-900',
      title: title || 'Transform Your Tech Team Today',
      subtitle: subtitle || 'Access elite Indian engineers within 48 hours',
      primaryCTA: 'Get Matched with Engineers',
      secondaryCTA: 'View Success Stories',
      icon: ArrowRight
    },
    urgent: {
      bgColor: 'bg-gradient-to-r from-orange-500 to-red-500',
      textColor: 'text-white',
      title: title || 'Limited Time: Fast-Track Your Project',
      subtitle: subtitle || 'Get priority access to our top 1% engineers this month',
      primaryCTA: 'Claim Priority Access',
      secondaryCTA: 'Learn More',
      icon: Clock
    },
    consultation: {
      bgColor: 'bg-gradient-to-r from-green-500 to-emerald-500',
      textColor: 'text-white',
      title: title || 'Free Strategy Session Available',
      subtitle: subtitle || 'Get personalized recommendations for your development needs',
      primaryCTA: 'Book Strategy Session',
      secondaryCTA: 'Download Guide',
      icon: Phone
    }
  };

  const currentVariant = variants[variant];
  const IconComponent = currentVariant.icon;

  const benefits = [
    { icon: Clock, text: '48-hour engineer deployment' },
    { icon: Shield, text: 'Pre-vetted talent guarantee' },
    { icon: MessageCircle, text: 'Dedicated project manager' },
    { icon: FileText, text: 'Transparent progress tracking' }
  ];

  const urgencyIndicators = [
    '⚡ Only 12 slots available this month',
    '🔥 High demand - book quickly',
    '⭐ Top engineers filling up fast'
  ];

  return (
    <div className={`py-16 ${currentVariant.bgColor}`}>
      <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
        <Card className={`border-0 shadow-2xl overflow-hidden ${
          variant === 'secondary' ? 'bg-white' : 'bg-white/10 backdrop-blur-sm'
        }`}>
          <CardContent className="p-8 lg:p-12">
            <div className="text-center mb-8">
              <div className="flex justify-center mb-4">
                <div className={`w-16 h-16 ${
                  variant === 'secondary' ? 'bg-primary' : 'bg-white/20'
                } rounded-full flex items-center justify-center`}>
                  <IconComponent className={`w-8 h-8 ${
                    variant === 'secondary' ? 'text-white' : 'text-white'
                  }`} />
                </div>
              </div>
              
              <h2 className={`text-4xl font-bold mb-4 ${
                variant === 'secondary' ? 'text-slate-900' : 'text-white'
              }`}>
                {currentVariant.title}
              </h2>
              
              <p className={`text-xl mb-6 ${
                variant === 'secondary' ? 'text-slate-600' : 'text-white/90'
              }`}>
                {currentVariant.subtitle}
              </p>

              {showUrgency && variant === 'urgent' && (
                <div className="flex flex-wrap justify-center gap-2 mb-6">
                  {urgencyIndicators.map((indicator, index) => (
                    <Badge key={index} className="bg-white/20 text-white border-white/30">
                      {indicator}
                    </Badge>
                  ))}
                </div>
              )}
            </div>

            {showBenefits && (
              <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-4 mb-8">
                {benefits.map((benefit, index) => (
                  <div key={index} className={`flex items-center p-4 rounded-lg ${
                    variant === 'secondary' 
                      ? 'bg-blue-50 text-slate-700' 
                      : 'bg-white/10 text-white'
                  }`}>
                    <benefit.icon className="w-5 h-5 mr-3 flex-shrink-0" />
                    <span className="text-sm font-medium">{benefit.text}</span>
                  </div>
                ))}
              </div>
            )}

            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <Button 
                className={`px-8 py-4 text-lg font-semibold ${
                  variant === 'secondary'
                    ? 'bg-primary hover:bg-blue-700 text-white'
                    : 'bg-white hover:bg-gray-100 text-slate-900'
                }`}
                onClick={() => {
                  // Scroll to contact form
                  document.getElementById('contact')?.scrollIntoView({ behavior: 'smooth' });
                }}
              >
                {currentVariant.primaryCTA}
                <ArrowRight className="w-5 h-5 ml-2" />
              </Button>
              
              <Button 
                variant="outline" 
                className={`px-8 py-4 text-lg font-semibold ${
                  variant === 'secondary'
                    ? 'border-primary text-primary hover:bg-primary hover:text-white'
                    : 'border-white text-white hover:bg-white hover:text-slate-900'
                }`}
              >
                {currentVariant.secondaryCTA}
              </Button>
            </div>

            <div className={`text-center mt-6 text-sm ${
              variant === 'secondary' ? 'text-slate-500' : 'text-white/70'
            }`}>
              <p>✓ No setup fees • ✓ Cancel anytime • ✓ 30-day satisfaction guarantee</p>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}