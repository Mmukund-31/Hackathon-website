import { Card, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Globe, Users, Building2, TrendingUp } from 'lucide-react';
import { useLanguage } from '@/lib/i18n';

interface RegionalData {
  region: string;
  flag: string;
  marketInsights: {
    totalCompanies: string;
    growthRate: string;
    topIndustries: string[];
    averageSavings: string;
  };
  culturalFactors: string[];
  businessPractices: string[];
  successMetrics: {
    clientsServed: number;
    satisfaction: string;
    repeatBusiness: string;
  };
  caseExample: {
    company: string;
    industry: string;
    challenge: string;
    outcome: string;
  };
}

export default function LocalizedContent() {
  const { language } = useLanguage();

  const regionalData: Record<string, RegionalData> = {
    ja: {
      region: 'Japan',
      flag: '🇯🇵',
      marketInsights: {
        totalCompanies: '2,500+',
        growthRate: '23%',
        topIndustries: ['Fintech', 'E-commerce', 'Gaming', 'Healthcare Tech'],
        averageSavings: '¥150M'
      },
      culturalFactors: [
        'Deep respect for quality and attention to detail',
        'Preference for long-term partnerships over quick fixes',
        'Strong emphasis on process documentation and compliance',
        'Value consensus-building and collaborative decision making'
      ],
      businessPractices: [
        'Detailed project planning with comprehensive documentation',
        'Regular status meetings with structured reporting',
        'Emphasis on risk mitigation and quality assurance',
        'Integration with existing enterprise systems and workflows'
      ],
      successMetrics: {
        clientsServed: 150,
        satisfaction: '96%',
        repeatBusiness: '89%'
      },
      caseExample: {
        company: 'Tokyo Financial Services',
        industry: 'Banking',
        challenge: 'Needed to modernize legacy banking systems while maintaining strict regulatory compliance',
        outcome: 'Delivered a secure, scalable platform that increased customer engagement by 300%'
      }
    },
    ko: {
      region: 'South Korea',
      flag: '🇰🇷',
      marketInsights: {
        totalCompanies: '1,800+',
        growthRate: '31%',
        topIndustries: ['Gaming', 'E-commerce', 'Entertainment Tech', 'Manufacturing'],
        averageSavings: '₩2.1B'
      },
      culturalFactors: [
        'Fast-paced development cycles with rapid iteration',
        'Strong focus on mobile-first and user experience',
        'Emphasis on innovation and cutting-edge technology',
        'Collaborative team culture with flat hierarchies'
      ],
      businessPractices: [
        'Agile development with short sprint cycles',
        'Continuous integration and rapid deployment',
        'Heavy emphasis on mobile optimization',
        'Integration with popular Korean platforms and services'
      ],
      successMetrics: {
        clientsServed: 120,
        satisfaction: '94%',
        repeatBusiness: '85%'
      },
      caseExample: {
        company: 'Seoul Commerce Group',
        industry: 'E-commerce',
        challenge: 'Required scalable platform to handle massive traffic during shopping festivals',
        outcome: 'Built infrastructure that handles 10x traffic spikes with 99.99% uptime'
      }
    },
    zh: {
      region: 'Greater China',
      flag: '🇨🇳',
      marketInsights: {
        totalCompanies: '3,200+',
        growthRate: '28%',
        topIndustries: ['E-commerce', 'Fintech', 'IoT', 'AI/Machine Learning'],
        averageSavings: '¥18M'
      },
      culturalFactors: [
        'Rapid scaling and aggressive growth targets',
        'Integration with Chinese ecosystem and platforms',
        'Emphasis on data-driven decision making',
        'Strong focus on operational efficiency'
      ],
      businessPractices: [
        'Rapid prototyping and iterative development',
        'Integration with WeChat, Alipay, and other platforms',
        'Compliance with Chinese data regulations',
        'Focus on performance optimization and cost efficiency'
      ],
      successMetrics: {
        clientsServed: 200,
        satisfaction: '92%',
        repeatBusiness: '82%'
      },
      caseExample: {
        company: 'Shanghai Tech Innovations',
        industry: 'IoT',
        challenge: 'Needed to build smart city infrastructure with real-time data processing',
        outcome: 'Deployed system processing 50M+ data points daily with 99.9% accuracy'
      }
    },
    en: {
      region: 'Asia-Pacific',
      flag: '🌏',
      marketInsights: {
        totalCompanies: '500+',
        growthRate: '35%',
        topIndustries: ['Fintech', 'Healthcare', 'Logistics', 'EdTech'],
        averageSavings: '$2.8M'
      },
      culturalFactors: [
        'Diverse multicultural business environment',
        'English as primary business communication',
        'International best practices and standards',
        'Cross-border collaboration and compliance'
      ],
      businessPractices: [
        'International development standards and practices',
        'Multi-timezone coordination and communication',
        'Compliance with various regional regulations',
        'Integration with global platforms and services'
      ],
      successMetrics: {
        clientsServed: 80,
        satisfaction: '95%',
        repeatBusiness: '88%'
      },
      caseExample: {
        company: 'Singapore Manufacturing Corp',
        industry: 'Manufacturing',
        challenge: 'Required AI-powered quality control system for international standards',
        outcome: 'Achieved 85% defect reduction and 340% ROI within first year'
      }
    }
  };

  const currentRegion = regionalData[language] || regionalData.en;

  return (
    <div className="bg-white py-16" id="regional-insights">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-12">
          <div className="inline-flex items-center bg-primary/10 text-primary px-4 py-2 rounded-full text-sm font-medium mb-4">
            <Globe className="w-4 h-4 mr-2" />
            Regional Expertise
          </div>
          <h2 className="text-4xl font-bold text-slate-900 mb-4">
            {currentRegion.flag} Tailored Solutions for {currentRegion.region}
          </h2>
          <p className="text-xl text-slate-600 max-w-3xl mx-auto">
            We understand your market, culture, and business practices to deliver 
            solutions that truly fit your needs
          </p>
        </div>

        {/* Market Insights */}
        <div className="grid lg:grid-cols-4 gap-6 mb-12">
          <Card className="border-0 shadow-lg text-center">
            <CardContent className="p-6">
              <Building2 className="w-8 h-8 text-primary mx-auto mb-3" />
              <div className="text-2xl font-bold text-slate-900 mb-1">
                {currentRegion.marketInsights.totalCompanies}
              </div>
              <div className="text-sm text-slate-600">Companies Served</div>
            </CardContent>
          </Card>
          
          <Card className="border-0 shadow-lg text-center">
            <CardContent className="p-6">
              <TrendingUp className="w-8 h-8 text-green-600 mx-auto mb-3" />
              <div className="text-2xl font-bold text-slate-900 mb-1">
                {currentRegion.marketInsights.growthRate}
              </div>
              <div className="text-sm text-slate-600">YoY Growth</div>
            </CardContent>
          </Card>
          
          <Card className="border-0 shadow-lg text-center">
            <CardContent className="p-6">
              <Users className="w-8 h-8 text-blue-600 mx-auto mb-3" />
              <div className="text-2xl font-bold text-slate-900 mb-1">
                {currentRegion.successMetrics.satisfaction}
              </div>
              <div className="text-sm text-slate-600">Client Satisfaction</div>
            </CardContent>
          </Card>
          
          <Card className="border-0 shadow-lg text-center">
            <CardContent className="p-6">
              <Globe className="w-8 h-8 text-purple-600 mx-auto mb-3" />
              <div className="text-2xl font-bold text-slate-900 mb-1">
                {currentRegion.marketInsights.averageSavings}
              </div>
              <div className="text-sm text-slate-600">Average Savings</div>
            </CardContent>
          </Card>
        </div>

        <div className="grid lg:grid-cols-2 gap-12">
          {/* Cultural Understanding */}
          <div>
            <h3 className="text-2xl font-bold text-slate-900 mb-6">
              Cultural Intelligence
            </h3>
            <p className="text-slate-600 mb-6">
              Our engineers are trained to understand and respect {currentRegion.region}'s 
              unique business culture and practices.
            </p>
            
            <div className="space-y-4 mb-6">
              {currentRegion.culturalFactors.map((factor, index) => (
                <div key={index} className="flex items-start">
                  <div className="w-2 h-2 bg-primary rounded-full mt-2 mr-3 flex-shrink-0"></div>
                  <span className="text-slate-700">{factor}</span>
                </div>
              ))}
            </div>

            <h4 className="text-lg font-semibold text-slate-900 mb-4">
              Top Industries We Serve
            </h4>
            <div className="flex flex-wrap gap-2">
              {currentRegion.marketInsights.topIndustries.map((industry, index) => (
                <Badge key={index} variant="outline" className="text-sm">
                  {industry}
                </Badge>
              ))}
            </div>
          </div>

          {/* Business Practices */}
          <div>
            <h3 className="text-2xl font-bold text-slate-900 mb-6">
              Localized Business Practices
            </h3>
            <p className="text-slate-600 mb-6">
              We adapt our development processes to align with {currentRegion.region}'s 
              business standards and expectations.
            </p>
            
            <div className="space-y-4 mb-8">
              {currentRegion.businessPractices.map((practice, index) => (
                <div key={index} className="flex items-start">
                  <div className="w-2 h-2 bg-green-500 rounded-full mt-2 mr-3 flex-shrink-0"></div>
                  <span className="text-slate-700">{practice}</span>
                </div>
              ))}
            </div>

            {/* Success Story */}
            <Card className="bg-gradient-to-br from-blue-50 to-indigo-50 border-l-4 border-l-primary">
              <CardContent className="p-6">
                <h4 className="font-semibold text-slate-900 mb-2">
                  Success Story: {currentRegion.caseExample.company}
                </h4>
                <Badge variant="outline" className="mb-3">
                  {currentRegion.caseExample.industry}
                </Badge>
                <p className="text-slate-600 text-sm mb-3">
                  <strong>Challenge:</strong> {currentRegion.caseExample.challenge}
                </p>
                <p className="text-slate-600 text-sm">
                  <strong>Outcome:</strong> {currentRegion.caseExample.outcome}
                </p>
              </CardContent>
            </Card>
          </div>
        </div>

        {/* Regional CTA */}
        <div className="text-center mt-12">
          <h3 className="text-2xl font-bold text-slate-900 mb-4">
            Ready to Start Your {currentRegion.region} Success Story?
          </h3>
          <p className="text-slate-600 mb-6">
            Connect with engineers who understand your market and can deliver 
            results that exceed expectations
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Button className="bg-primary hover:bg-blue-700 px-8 py-3">
              Schedule Regional Consultation
            </Button>
            <Button variant="outline" className="px-8 py-3">
              View {currentRegion.region} Case Studies
            </Button>
          </div>
        </div>
      </div>
    </div>
  );
}