import { AlertTriangle, DollarSign, Clock, Users, TrendingUp, Rocket, CheckCircle } from "lucide-react";
import { Badge } from "@/components/ui/badge";

export default function ProblemSolution() {
  return (
    <section className="py-20 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="text-3xl lg:text-5xl font-bold text-slate-900 mb-6">
            The Challenge Asian Companies Face
          </h2>
          <p className="text-xl text-slate-600 max-w-3xl mx-auto">
            Growing tech companies in Asia struggle with talent shortages, high costs, and lengthy hiring processes that slow down innovation.
          </p>
        </div>
        
        <div className="grid md:grid-cols-3 gap-8 mb-20">
          <div className="text-center p-8 bg-red-50 rounded-2xl border border-red-100">
            <div className="w-16 h-16 bg-red-100 rounded-2xl flex items-center justify-center mx-auto mb-6">
              <AlertTriangle className="w-8 h-8 text-red-600" />
            </div>
            <h3 className="text-xl font-bold text-slate-900 mb-4">Talent Shortage</h3>
            <p className="text-slate-600">Limited pool of qualified engineers in local markets, making it difficult to find the right skills for complex projects.</p>
          </div>
          
          <div className="text-center p-8 bg-orange-50 rounded-2xl border border-orange-100">
            <div className="w-16 h-16 bg-orange-100 rounded-2xl flex items-center justify-center mx-auto mb-6">
              <DollarSign className="w-8 h-8 text-orange-600" />
            </div>
            <h3 className="text-xl font-bold text-slate-900 mb-4">High Costs</h3>
            <p className="text-slate-600">Expensive local talent and recruitment fees that strain budgets, especially for startups and growing companies.</p>
          </div>
          
          <div className="text-center p-8 bg-yellow-50 rounded-2xl border border-yellow-100">
            <div className="w-16 h-16 bg-yellow-100 rounded-2xl flex items-center justify-center mx-auto mb-6">
              <Clock className="w-8 h-8 text-yellow-600" />
            </div>
            <h3 className="text-xl font-bold text-slate-900 mb-4">Slow Hiring</h3>
            <p className="text-slate-600">Lengthy recruitment processes that delay project timelines and miss critical market opportunities.</p>
          </div>
        </div>
        
        <div className="text-center mb-16">
          <div className="inline-flex items-center bg-gradient-to-r from-green-100 to-emerald-100 text-green-800 px-6 py-3 rounded-full text-lg font-bold mb-6 border border-green-200">
            <CheckCircle className="w-6 h-6 mr-2" />
            Tech Japan Solution
          </div>
          <h2 className="text-4xl lg:text-6xl font-bold text-slate-900 mb-8 leading-tight">
            <span className="block text-3xl lg:text-4xl text-slate-600 mb-2">Transform Your Business with</span>
            <span className="bg-gradient-to-r from-green-600 to-emerald-600 bg-clip-text text-transparent">
              Instant Engineering Access
            </span>
          </h2>
          <div className="max-w-4xl mx-auto">
            <p className="text-2xl text-slate-700 font-semibold mb-4">
              Cut costs by 60%. Start in 48 hours. Scale without limits.
            </p>
            <p className="text-xl text-slate-600">
              Our vetted Indian engineers integrate seamlessly with Asian companies, delivering world-class results at a fraction of traditional costs.
            </p>
          </div>
        </div>
        
        <div className="grid md:grid-cols-3 gap-8">
          <div className="text-center p-8 bg-blue-50 rounded-2xl border border-blue-100">
            <div className="w-16 h-16 bg-primary rounded-2xl flex items-center justify-center mx-auto mb-6">
              <Users className="w-8 h-8 text-white" />
            </div>
            <h3 className="text-xl font-bold text-slate-900 mb-4">Vetted Talent Pool</h3>
            <p className="text-slate-600 mb-4">Access to over 6,000 pre-screened Indian engineers with proven track records in cutting-edge technologies.</p>
            <div className="flex justify-center">
              <Badge className="bg-green-600 text-white px-3 py-1 rounded-full text-sm font-semibold">
                95% Match Rate
              </Badge>
            </div>
          </div>
          
          <div className="text-center p-8 bg-green-50 rounded-2xl border border-green-100">
            <div className="w-16 h-16 bg-green-600 rounded-2xl flex items-center justify-center mx-auto mb-6">
              <TrendingUp className="w-8 h-8 text-white" />
            </div>
            <h3 className="text-xl font-bold text-slate-900 mb-4">Cost Effective</h3>
            <p className="text-slate-600 mb-4">Save up to 60% on development costs while maintaining high quality standards and meeting project deadlines.</p>
            <div className="flex justify-center">
              <Badge className="bg-green-600 text-white px-3 py-1 rounded-full text-sm font-semibold">
                60% Cost Savings
              </Badge>
            </div>
          </div>
          
          <div className="text-center p-8 bg-purple-50 rounded-2xl border border-purple-100">
            <div className="w-16 h-16 bg-purple-600 rounded-2xl flex items-center justify-center mx-auto mb-6">
              <Rocket className="w-8 h-8 text-white" />
            </div>
            <h3 className="text-xl font-bold text-slate-900 mb-4">Rapid Deployment</h3>
            <p className="text-slate-600 mb-4">Start working with qualified engineers within 48 hours. No lengthy interviews or complicated onboarding processes.</p>
            <div className="flex justify-center">
              <Badge className="bg-purple-600 text-white px-3 py-1 rounded-full text-sm font-semibold">
                48 Hour Start
              </Badge>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
