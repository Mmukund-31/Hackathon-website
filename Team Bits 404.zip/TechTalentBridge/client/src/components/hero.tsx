import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Star, Search, Play, Code, Zap, Globe, ArrowRight } from "lucide-react";

export default function Hero() {
  const scrollToContact = () => {
    const element = document.getElementById("contact");
    if (element) {
      element.scrollIntoView({ behavior: "smooth" });
    }
  };

  const handleWatchDemo = () => {
    // Implementation: Open demo modal or redirect to demo page
    alert("Demo functionality would be implemented here");
  };

  return (
    <section className="relative bg-gradient-to-br from-slate-50 via-blue-50 to-indigo-100 py-20 lg:py-32 overflow-hidden">
      {/* Tech-inspired background elements */}
      <div className="absolute inset-0 opacity-5">
        <div className="absolute top-20 left-10 w-64 h-64 bg-primary rounded-full blur-3xl"></div>
        <div className="absolute bottom-20 right-10 w-96 h-96 bg-purple-500 rounded-full blur-3xl"></div>
      </div>
      
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative">
        <div className="grid lg:grid-cols-2 gap-12 items-center">
          <div>
            <Badge className="inline-flex items-center bg-gradient-to-r from-blue-100 to-indigo-100 text-primary px-6 py-3 rounded-full text-base font-semibold mb-8 border border-blue-200 shadow-sm">
              <Zap className="w-5 h-5 text-yellow-500 mr-2" />
              <span className="bg-gradient-to-r from-primary to-indigo-600 bg-clip-text text-transparent">
                500+ Tech Companies Trust Us
              </span>
            </Badge>
            
            <h1 className="text-5xl lg:text-7xl font-extrabold text-slate-900 leading-tight mb-8">
              <span className="block text-4xl lg:text-5xl font-bold text-slate-700 mb-2">Scale Fast with</span>
              <span className="bg-gradient-to-r from-primary via-blue-600 to-indigo-600 bg-clip-text text-transparent">
                Elite Indian Engineers
              </span>
            </h1>
            
            <p className="text-2xl text-slate-600 mb-10 leading-relaxed font-medium">
              <strong className="text-slate-800">60% cost reduction.</strong> <strong className="text-slate-800">48-hour deployment.</strong> <strong className="text-slate-800">Pre-vetted talent.</strong>
              <br />
              <span className="text-xl text-slate-500 mt-2 block">
                Transform your tech projects with our proven engineering expertise.
              </span>
            </p>
            
            <div className="flex flex-col sm:flex-row gap-6 mb-10">
              <Button 
                onClick={scrollToContact}
                size="lg"
                className="bg-gradient-to-r from-primary to-blue-700 hover:from-blue-700 hover:to-primary text-white px-10 py-5 rounded-xl font-bold text-xl transition-all duration-300 shadow-lg hover:shadow-xl transform hover:-translate-y-1"
              >
                <Search className="w-6 h-6 mr-3" />
                Start Hiring Now
                <ArrowRight className="w-5 h-5 ml-2" />
              </Button>
              <Button 
                onClick={handleWatchDemo}
                variant="outline"
                size="lg"
                className="border-2 border-slate-400 hover:border-primary text-slate-700 hover:text-primary px-10 py-5 rounded-xl font-bold text-xl transition-all duration-300 bg-white/80 backdrop-blur-sm"
              >
                <Play className="w-6 h-6 mr-3" />
                See How It Works
              </Button>
            </div>
            
            <div className="flex items-center gap-6 text-base text-slate-600">
              <div className="flex items-center gap-3">
                <Globe className="w-5 h-5 text-primary" />
                <span className="font-semibold">Global Reach</span>
              </div>
              <div className="flex items-center gap-3">
                <Code className="w-5 h-5 text-green-600" />
                <span className="font-semibold">Tech Excellence</span>
              </div>
              <div className="flex items-center gap-3">
                <Zap className="w-5 h-5 text-yellow-500" />
                <span className="font-semibold">Rapid Deployment</span>
              </div>
            </div>
          </div>
          
          <div className="relative">
            {/* Floating tech elements */}
            <div className="absolute -top-6 -right-6 w-20 h-20 bg-gradient-to-r from-blue-500 to-purple-600 rounded-2xl flex items-center justify-center rotate-12 shadow-lg z-20">
              <Code className="w-10 h-10 text-white" />
            </div>
            <div className="absolute -bottom-4 -left-4 w-16 h-16 bg-gradient-to-r from-green-500 to-teal-600 rounded-xl flex items-center justify-center -rotate-12 shadow-lg z-20">
              <Zap className="w-8 h-8 text-white" />
            </div>
            
            <div className="relative z-10">
              <div className="absolute inset-0 bg-gradient-to-tr from-primary/10 to-purple-500/10 rounded-3xl transform rotate-2 shadow-2xl"></div>
              <div className="relative bg-white/95 backdrop-blur-sm rounded-2xl shadow-2xl p-8 border border-slate-200/50">
                <div className="text-center mb-6">
                  <div className="w-20 h-20 bg-gradient-to-r from-primary to-indigo-600 rounded-2xl flex items-center justify-center mx-auto mb-4 shadow-lg">
                    <svg className="w-10 h-10 text-white" fill="currentColor" viewBox="0 0 24 24">
                      <path d="M12 2L2 7v10c0 5.55 3.84 10 9 10s9-4.45 9-10V7l-10-5z"/>
                      <path d="M12 7v10m-3-7h6"/>
                    </svg>
                  </div>
                  <h3 className="text-2xl font-bold text-slate-900 mb-3">Live Talent Dashboard</h3>
                  <p className="text-slate-600 text-lg">Real-time access to our engineering network</p>
                </div>
                
                <div className="space-y-4">
                  <div className="flex items-center justify-between p-4 bg-gradient-to-r from-blue-50 to-indigo-50 rounded-xl border border-blue-100">
                    <div className="flex items-center">
                      <div className="w-10 h-10 bg-gradient-to-r from-blue-500 to-blue-600 rounded-xl flex items-center justify-center mr-4 shadow-sm">
                        <span className="text-white font-bold">⚛️</span>
                      </div>
                      <div>
                        <span className="font-bold text-slate-900">React/Next.js</span>
                        <div className="text-sm text-slate-500">Frontend Specialists</div>
                      </div>
                    </div>
                    <div className="text-right">
                      <span className="text-2xl font-bold text-green-600">2,340+</span>
                      <div className="text-xs text-green-600">Available Now</div>
                    </div>
                  </div>
                  
                  <div className="flex items-center justify-between p-4 bg-gradient-to-r from-yellow-50 to-orange-50 rounded-xl border border-yellow-100">
                    <div className="flex items-center">
                      <div className="w-10 h-10 bg-gradient-to-r from-yellow-500 to-orange-500 rounded-xl flex items-center justify-center mr-4 shadow-sm">
                        <span className="text-white font-bold">🐍</span>
                      </div>
                      <div>
                        <span className="font-bold text-slate-900">Python/AI</span>
                        <div className="text-sm text-slate-500">Backend & ML</div>
                      </div>
                    </div>
                    <div className="text-right">
                      <span className="text-2xl font-bold text-green-600">1,890+</span>
                      <div className="text-xs text-green-600">Available Now</div>
                    </div>
                  </div>
                  
                  <div className="flex items-center justify-between p-4 bg-gradient-to-r from-purple-50 to-pink-50 rounded-xl border border-purple-100">
                    <div className="flex items-center">
                      <div className="w-10 h-10 bg-gradient-to-r from-purple-500 to-pink-500 rounded-xl flex items-center justify-center mr-4 shadow-sm">
                        <span className="text-white font-bold">📱</span>
                      </div>
                      <div>
                        <span className="font-bold text-slate-900">Mobile Apps</span>
                        <div className="text-sm text-slate-500">iOS & Android</div>
                      </div>
                    </div>
                    <div className="text-right">
                      <span className="text-2xl font-bold text-green-600">1,560+</span>
                      <div className="text-xs text-green-600">Available Now</div>
                    </div>
                  </div>
                </div>
                
                <div className="mt-6 p-4 bg-gradient-to-r from-green-50 to-emerald-50 rounded-xl border border-green-100">
                  <div className="flex items-center justify-center">
                    <div className="flex items-center text-green-700">
                      <div className="w-3 h-3 bg-green-500 rounded-full mr-2 animate-pulse"></div>
                      <span className="font-semibold">Live: 847 engineers online and ready</span>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
