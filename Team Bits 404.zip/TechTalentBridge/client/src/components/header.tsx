import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Menu, X } from "lucide-react";
import { useLanguage } from "@/lib/i18n";
import LanguageSwitcher from "@/components/language-switcher";

export default function Header() {
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  const { t } = useLanguage();

  const scrollToSection = (sectionId: string) => {
    const element = document.getElementById(sectionId);
    if (element) {
      element.scrollIntoView({ behavior: "smooth" });
    }
    setIsMobileMenuOpen(false);
  };

  return (
    <>
      <a href="#main-content" className="skip-link">
        Skip to main content
      </a>
      <header className="bg-white shadow-sm border-b border-slate-200 sticky top-0 z-50" role="banner">
        <nav className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8" role="navigation" aria-label="Main navigation">
        <div className="flex items-center justify-between h-16">
          {/* Logo - Extreme Left */}
          <div className="flex items-center">
            <div className="flex-shrink-0 flex items-center">
              <div className="flex items-center">
                {/* Talendy Logo - Orange square and green rectangle */}
                <div className="relative mr-3">
                  <div className="w-8 h-6 relative">
                    {/* Orange square */}
                    <div className="absolute top-0 left-0 w-4 h-4 bg-orange-500"></div>
                    {/* Green rectangle overlapping */}
                    <div className="absolute top-2 left-2 w-4 h-4 bg-green-600"></div>
                  </div>
                </div>
                <div className="flex flex-col">
                  <span className="text-lg font-bold text-slate-900 leading-tight">Talendy</span>
                  <span className="text-xs text-slate-500 leading-tight">By Tech Japan</span>
                </div>
              </div>
            </div>
          </div>
          
          {/* Navigation Items */}
          <div className="hidden lg:flex items-center space-x-6">
            <a 
              href="#services"
              onClick={(e) => {
                e.preventDefault();
                scrollToSection("services");
              }}
              className="text-slate-600 hover:text-primary px-2 py-1 text-sm font-medium transition-colors underline decoration-2 underline-offset-3"
            >
              {t('services')}
            </a>
            <a 
              href="#talent"
              onClick={(e) => {
                e.preventDefault();
                scrollToSection("talent");
              }}
              className="text-slate-600 hover:text-primary px-2 py-1 text-sm font-medium transition-colors underline decoration-2 underline-offset-3"
            >
              {t('talent')}
            </a>
            <a 
              href="#success"
              onClick={(e) => {
                e.preventDefault();
                scrollToSection("success");
              }}
              className="text-slate-600 hover:text-primary px-2 py-1 text-sm font-medium transition-colors underline decoration-2 underline-offset-3"
            >
              {t('success')}
            </a>
            <a 
              href="/news"
              className="text-slate-600 hover:text-primary px-2 py-1 text-sm font-medium transition-colors underline decoration-2 underline-offset-3"
            >
              News
            </a>
            <a 
              href="/faq"
              className="text-slate-600 hover:text-primary px-2 py-1 text-sm font-medium transition-colors underline decoration-2 underline-offset-3"
            >
              FAQ's
            </a>
            <a 
              href="/about-us"
              className="text-slate-600 hover:text-primary px-2 py-1 text-sm font-medium transition-colors underline decoration-2 underline-offset-3"
            >
              About Us
            </a>
          </div>
          
          {/* Right Side: Language + Download + For Students + Get Started */}
          <div className="flex items-center space-x-3">
            <LanguageSwitcher />
            <a 
              href="/download"
              className="text-slate-600 hover:text-primary px-2 py-1 text-sm font-medium transition-colors hidden md:inline-flex underline decoration-2 underline-offset-3"
            >
              Download
            </a>
            <Button 
              onClick={() => window.location.href = '/for-candidate'}
              variant="outline"
              className="border-primary text-primary hover:bg-primary hover:text-white px-4 py-2 rounded-lg font-semibold transition-colors hidden sm:inline-flex text-sm"
            >
              For Students
            </Button>
            <Button 
              onClick={() => scrollToSection("contact")}
              className="bg-primary hover:bg-blue-700 text-white px-4 py-2 rounded-lg font-semibold transition-colors hidden sm:inline-flex text-sm"
            >
              {t('getStarted')}
            </Button>
            <button 
              className="md:hidden text-slate-600 hover:text-primary"
              onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
            >
              {isMobileMenuOpen ? <X className="h-6 w-6" /> : <Menu className="h-6 w-6" />}
            </button>
          </div>
        </div>

        {/* Mobile menu */}
        {isMobileMenuOpen && (
          <div className="md:hidden">
            <div className="px-2 pt-2 pb-3 space-y-1 sm:px-3 bg-white border-t border-slate-200">
              <button 
                onClick={() => scrollToSection("services")}
                className="text-slate-600 hover:text-primary block px-3 py-2 text-base font-medium w-full text-left"
              >
                Services
              </button>
              <button 
                onClick={() => scrollToSection("talent")}
                className="text-slate-600 hover:text-primary block px-3 py-2 text-base font-medium w-full text-left"
              >
                Talent Pool
              </button>
              <button 
                onClick={() => scrollToSection("success")}
                className="text-slate-600 hover:text-primary block px-3 py-2 text-base font-medium w-full text-left"
              >
                Success Stories
              </button>
              <button 
                onClick={() => scrollToSection("contact")}
                className="text-slate-600 hover:text-primary block px-3 py-2 text-base font-medium w-full text-left"
              >
                Contact
              </button>
              <Button 
                onClick={() => scrollToSection("contact")}
                className="bg-primary hover:bg-blue-700 text-white w-full mt-4"
              >
                Get Started
              </Button>
            </div>
          </div>
        )}
        </nav>
      </header>
    </>
  );
}
