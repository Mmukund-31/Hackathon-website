import { useState } from 'react';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Play, Star, Building2, MapPin, Quote } from 'lucide-react';
import { useLanguage } from '@/lib/i18n';

interface VideoTestimonial {
  id: number;
  clientName: string;
  clientTitle: string;
  company: string;
  location: string;
  projectType: string;
  teamSize: number;
  duration: string;
  savings: string;
  rating: number;
  thumbnailUrl: string;
  videoUrl: string;
  quote: string;
  results: string[];
}

const testimonials: VideoTestimonial[] = [
  {
    id: 1,
    clientName: "Takeshi Yamamoto",
    clientTitle: "CTO",
    company: "TokyoTech Solutions",
    location: "Tokyo, Japan",
    projectType: "E-commerce Platform",
    teamSize: 5,
    duration: "8 months",
    savings: "65%",
    rating: 5,
    thumbnailUrl: "/api/placeholder/600/400",
    videoUrl: "https://example.com/testimonial1.mp4",
    quote: "Tech Japan delivered exceptional engineers who understood our business culture perfectly. The cost savings allowed us to expand our development team significantly.",
    results: ["Faster time to market", "60% cost reduction", "Seamless integration"]
  },
  {
    id: 2,
    clientName: "Sarah Kim",
    clientTitle: "Product Director",
    company: "Seoul Fintech Corp",
    location: "Seoul, South Korea",
    projectType: "Mobile Banking App",
    teamSize: 8,
    duration: "12 months",
    savings: "58%",
    rating: 5,
    thumbnailUrl: "/api/placeholder/600/400",
    videoUrl: "https://example.com/testimonial2.mp4",
    quote: "The quality of engineers from Tech Japan exceeded our expectations. They delivered a world-class mobile banking solution that our customers love.",
    results: ["500K+ app downloads", "4.8 app store rating", "Zero security issues"]
  }
];

export default function TestimonialVideo() {
  const [activeTestimonial, setActiveTestimonial] = useState(0);
  const [isPlaying, setIsPlaying] = useState(false);
  const { t } = useLanguage();

  const current = testimonials[activeTestimonial];

  return (
    <div className="bg-white py-16" id="testimonials">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-12">
          <div className="inline-flex items-center bg-primary/10 text-primary px-4 py-2 rounded-full text-sm font-medium mb-4">
            <Quote className="w-4 h-4 mr-2" />
            Client Success Stories
          </div>
          <h2 className="text-4xl font-bold text-slate-900 mb-4">
            Hear From Our Happy Clients
          </h2>
          <p className="text-xl text-slate-600 max-w-3xl mx-auto">
            Real stories from Asian companies who transformed their development with our engineers
          </p>
        </div>

        <div className="grid lg:grid-cols-2 gap-8 items-center">
          {/* Video Player */}
          <div className="relative">
            <Card className="border-0 shadow-xl overflow-hidden">
              <div className="relative aspect-video bg-slate-900">
                <img
                  src={current.thumbnailUrl}
                  alt={`${current.clientName} testimonial`}
                  className="w-full h-full object-cover"
                />
                <div className="absolute inset-0 bg-black/40 flex items-center justify-center">
                  <Button
                    onClick={() => setIsPlaying(true)}
                    className="bg-white/20 hover:bg-white/30 backdrop-blur-sm border-2 border-white/30 text-white p-6 rounded-full"
                  >
                    <Play className="w-8 h-8 ml-1" />
                  </Button>
                </div>
                
                {/* Client info overlay */}
                <div className="absolute bottom-4 left-4 right-4">
                  <div className="bg-white/90 backdrop-blur-sm rounded-lg p-4">
                    <div className="flex items-center space-x-3">
                      <div className="w-12 h-12 bg-primary rounded-full flex items-center justify-center text-white font-bold">
                        {current.clientName.split(' ').map(n => n[0]).join('')}
                      </div>
                      <div>
                        <h4 className="font-semibold text-slate-900">{current.clientName}</h4>
                        <p className="text-sm text-slate-600">{current.clientTitle}, {current.company}</p>
                        <div className="flex items-center mt-1">
                          {[...Array(5)].map((_, i) => (
                            <Star
                              key={i}
                              className={`w-4 h-4 ${
                                i < current.rating
                                  ? 'text-yellow-400 fill-current'
                                  : 'text-slate-300'
                              }`}
                            />
                          ))}
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </Card>

            {/* Testimonial selector */}
            <div className="flex justify-center mt-6 space-x-4">
              {testimonials.map((_, index) => (
                <button
                  key={index}
                  onClick={() => setActiveTestimonial(index)}
                  className={`w-3 h-3 rounded-full transition-colors ${
                    index === activeTestimonial ? 'bg-primary' : 'bg-slate-300'
                  }`}
                />
              ))}
            </div>
          </div>

          {/* Testimonial Details */}
          <div className="space-y-6">
            <div>
              <div className="flex items-center space-x-2 text-sm text-slate-500 mb-2">
                <MapPin className="w-4 h-4" />
                <span>{current.location}</span>
              </div>
              <h3 className="text-2xl font-bold text-slate-900 mb-2">{current.company}</h3>
              <p className="text-lg text-slate-600 italic leading-relaxed">
                "{current.quote}"
              </p>
            </div>

            {/* Project Stats */}
            <div className="grid grid-cols-2 gap-4">
              <Card className="border border-slate-200">
                <CardContent className="p-4 text-center">
                  <div className="text-2xl font-bold text-primary">{current.teamSize}</div>
                  <div className="text-sm text-slate-600">Engineers</div>
                </CardContent>
              </Card>
              <Card className="border border-slate-200">
                <CardContent className="p-4 text-center">
                  <div className="text-2xl font-bold text-primary">{current.duration}</div>
                  <div className="text-sm text-slate-600">Duration</div>
                </CardContent>
              </Card>
              <Card className="border border-slate-200">
                <CardContent className="p-4 text-center">
                  <div className="text-2xl font-bold text-green-600">{current.savings}</div>
                  <div className="text-sm text-slate-600">Cost Savings</div>
                </CardContent>
              </Card>
              <Card className="border border-slate-200">
                <CardContent className="p-4 text-center">
                  <div className="text-2xl font-bold text-primary">{current.projectType}</div>
                  <div className="text-sm text-slate-600">Project Type</div>
                </CardContent>
              </Card>
            </div>

            {/* Results */}
            <div>
              <h4 className="font-semibold text-slate-900 mb-3">Key Results</h4>
              <div className="space-y-2">
                {current.results.map((result, index) => (
                  <div key={index} className="flex items-center text-slate-600">
                    <div className="w-2 h-2 bg-green-500 rounded-full mr-3"></div>
                    {result}
                  </div>
                ))}
              </div>
            </div>

            <div className="flex space-x-4">
              <Button className="bg-primary hover:bg-blue-700">
                Start Your Success Story
              </Button>
              <Button variant="outline">
                Watch More Testimonials
              </Button>
            </div>
          </div>
        </div>

        {/* Trust indicators */}
        <div className="mt-16 text-center">
          <p className="text-slate-500 mb-6">Trusted by companies across Asia-Pacific</p>
          <div className="flex justify-center items-center space-x-8 opacity-60">
            {[1, 2, 3, 4, 5].map((i) => (
              <div key={i} className="w-24 h-12 bg-slate-200 rounded flex items-center justify-center">
                <Building2 className="w-6 h-6 text-slate-400" />
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}