import { useEffect } from 'react';
import { useLanguage } from '@/lib/i18n';

interface SEOHeadProps {
  title?: string;
  description?: string;
  keywords?: string;
  canonical?: string;
  ogImage?: string;
  structuredData?: object;
}

export default function SEOHead({
  title,
  description,
  keywords,
  canonical,
  ogImage,
  structuredData
}: SEOHeadProps) {
  const { language } = useLanguage();

  const defaultSEO = {
    en: {
      title: "Tech Japan by Talendy - Elite Indian Engineers | 60% Cost Reduction | 48-Hour Deployment",
      description: "Transform your tech projects with elite Indian engineers. 60% cost reduction, 48-hour deployment, pre-vetted talent. Trusted by leading Asian companies for web development, AI/ML, mobile apps, and blockchain projects.",
      keywords: "Indian engineers, Asian tech companies, software development outsourcing, cost reduction, pre-vetted developers, Tech Japan, Talendy, web development, AI ML engineers, mobile app development, blockchain development"
    },
    ja: {
      title: "Tech Japan by Talendy - エリートインドエンジニア | 60%コスト削減 | 48時間配備",
      description: "エリートインドエンジニアでテクノロジープロジェクトを変革。60%コスト削減、48時間配備、事前審査済み人材。ウェブ開発、AI/ML、モバイルアプリ、ブロックチェーンプロジェクトでアジア主要企業から信頼。",
      keywords: "インドエンジニア, アジア技術企業, ソフトウェア開発アウトソーシング, コスト削減, 事前審査済み開発者, Tech Japan, Talendy, ウェブ開発, AI MLエンジニア, モバイルアプリ開発"
    },
    ko: {
      title: "Tech Japan by Talendy - 엘리트 인도 엔지니어 | 60% 비용 절감 | 48시간 배포",
      description: "엘리트 인도 엔지니어로 기술 프로젝트를 혁신하세요. 60% 비용 절감, 48시간 배포, 사전 검증된 인재. 웹 개발, AI/ML, 모바일 앱, 블록체인 프로젝트에서 아시아 주요 기업들의 신뢰.",
      keywords: "인도 엔지니어, 아시아 기술 기업, 소프트웨어 개발 아웃소싱, 비용 절감, 사전 검증된 개발자, Tech Japan, Talendy, 웹 개발, AI ML 엔지니어, 모바일 앱 개발"
    },
    zh: {
      title: "Tech Japan by Talendy - 精英印度工程师 | 60%成本降低 | 48小时部署",
      description: "用精英印度工程师改变您的技术项目。60%成本降低，48小时部署，预审人才。在网页开发、AI/ML、移动应用和区块链项目中获得亚洲领先公司信赖。",
      keywords: "印度工程师, 亚洲技术公司, 软件开发外包, 成本降低, 预审开发者, Tech Japan, Talendy, 网页开发, AI ML工程师, 移动应用开发"
    }
  };

  const currentSEO = defaultSEO[language as keyof typeof defaultSEO] || defaultSEO.en;

  useEffect(() => {
    // Update document title
    document.title = title || currentSEO.title;

    // Update meta description
    let metaDescription = document.querySelector('meta[name="description"]');
    if (metaDescription) {
      metaDescription.setAttribute('content', description || currentSEO.description);
    }

    // Update meta keywords
    let metaKeywords = document.querySelector('meta[name="keywords"]');
    if (!metaKeywords) {
      metaKeywords = document.createElement('meta');
      metaKeywords.setAttribute('name', 'keywords');
      document.head.appendChild(metaKeywords);
    }
    metaKeywords.setAttribute('content', keywords || currentSEO.keywords);

    // Update canonical URL
    let canonicalLink = document.querySelector('link[rel="canonical"]');
    if (canonical) {
      if (!canonicalLink) {
        canonicalLink = document.createElement('link');
        canonicalLink.setAttribute('rel', 'canonical');
        document.head.appendChild(canonicalLink);
      }
      canonicalLink.setAttribute('href', canonical);
    }

    // Update Open Graph tags
    const ogTags = [
      { property: 'og:title', content: title || currentSEO.title },
      { property: 'og:description', content: description || currentSEO.description },
      { property: 'og:image', content: ogImage || 'https://www.talendy.world/og-image.jpg' },
      { property: 'og:url', content: canonical || window.location.href },
      { property: 'og:type', content: 'website' },
      { property: 'og:site_name', content: 'Tech Japan by Talendy' },
      { property: 'og:locale', content: language === 'ja' ? 'ja_JP' : language === 'ko' ? 'ko_KR' : language === 'zh' ? 'zh_CN' : 'en_US' }
    ];

    ogTags.forEach(tag => {
      let metaTag = document.querySelector(`meta[property="${tag.property}"]`);
      if (!metaTag) {
        metaTag = document.createElement('meta');
        metaTag.setAttribute('property', tag.property);
        document.head.appendChild(metaTag);
      }
      metaTag.setAttribute('content', tag.content);
    });

    // Update Twitter Card tags
    const twitterTags = [
      { name: 'twitter:card', content: 'summary_large_image' },
      { name: 'twitter:title', content: title || currentSEO.title },
      { name: 'twitter:description', content: description || currentSEO.description },
      { name: 'twitter:image', content: ogImage || 'https://www.talendy.world/twitter-image.jpg' }
    ];

    twitterTags.forEach(tag => {
      let metaTag = document.querySelector(`meta[name="${tag.name}"]`);
      if (!metaTag) {
        metaTag = document.createElement('meta');
        metaTag.setAttribute('name', tag.name);
        document.head.appendChild(metaTag);
      }
      metaTag.setAttribute('content', tag.content);
    });

    // Add structured data
    if (structuredData) {
      let scriptTag = document.querySelector('script[type="application/ld+json"]');
      if (!scriptTag) {
        scriptTag = document.createElement('script');
        scriptTag.setAttribute('type', 'application/ld+json');
        document.head.appendChild(scriptTag);
      }
      scriptTag.textContent = JSON.stringify(structuredData);
    }

    // Add language alternatives
    const languageAlts = [
      { hreflang: 'en', href: 'https://www.talendy.world/en' },
      { hreflang: 'ja', href: 'https://www.talendy.world/ja' },
      { hreflang: 'ko', href: 'https://www.talendy.world/ko' },
      { hreflang: 'zh', href: 'https://www.talendy.world/zh' },
      { hreflang: 'x-default', href: 'https://www.talendy.world' }
    ];

    languageAlts.forEach(alt => {
      let linkTag = document.querySelector(`link[hreflang="${alt.hreflang}"]`);
      if (!linkTag) {
        linkTag = document.createElement('link');
        linkTag.setAttribute('rel', 'alternate');
        linkTag.setAttribute('hreflang', alt.hreflang);
        document.head.appendChild(linkTag);
      }
      linkTag.setAttribute('href', alt.href);
    });

  }, [title, description, keywords, canonical, ogImage, structuredData, language, currentSEO]);

  return null; // This component doesn't render anything
}