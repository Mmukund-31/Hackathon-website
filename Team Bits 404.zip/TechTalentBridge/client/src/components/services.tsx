import { Button } from "@/components/ui/button";
import { CheckCircle, Brain, Cloud, Shield, BarChart } from "lucide-react";

export default function Services() {
  const handleLearnMore = () => {
    console.log("Learn more clicked");
  };

  const handleViewProjects = () => {
    console.log("View projects clicked");
  };

  return (
    <section id="services" className="py-20 bg-slate-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="text-3xl lg:text-5xl font-bold text-slate-900 mb-6">
            Comprehensive Tech Solutions
          </h2>
          <p className="text-xl text-slate-600 max-w-3xl mx-auto">
            From web development to AI/ML, our Indian engineers deliver world-class solutions across all technology domains.
          </p>
        </div>
        
        <div className="grid lg:grid-cols-2 gap-12 items-center mb-20">
          <div>
            <h3 className="text-2xl font-bold text-slate-900 mb-6">Full-Stack Development</h3>
            <p className="text-lg text-slate-600 mb-8">
              Build scalable web applications with modern frameworks and technologies. Our engineers specialize in React, Vue, Angular, Node.js, Python, and more.
            </p>
            
            <div className="space-y-4 mb-8">
              <div className="flex items-center">
                <CheckCircle className="w-5 h-5 text-green-600 mr-3" />
                <span className="text-slate-700">Frontend & Backend Development</span>
              </div>
              <div className="flex items-center">
                <CheckCircle className="w-5 h-5 text-green-600 mr-3" />
                <span className="text-slate-700">API Design & Integration</span>
              </div>
              <div className="flex items-center">
                <CheckCircle className="w-5 h-5 text-green-600 mr-3" />
                <span className="text-slate-700">Database Architecture</span>
              </div>
              <div className="flex items-center">
                <CheckCircle className="w-5 h-5 text-green-600 mr-3" />
                <span className="text-slate-700">Cloud Deployment</span>
              </div>
            </div>
            
            <Button 
              onClick={handleLearnMore}
              className="bg-primary hover:bg-blue-700 text-white px-6 py-3 rounded-lg font-semibold transition-colors"
            >
              Learn More
            </Button>
          </div>
          
          <div className="relative">
            <div className="bg-white rounded-2xl shadow-lg p-8 border border-slate-200">
              <div className="grid grid-cols-2 gap-4 mb-6">
                <div className="bg-blue-50 p-4 rounded-lg text-center">
                  <div className="w-8 h-8 bg-blue-100 rounded-lg flex items-center justify-center mx-auto mb-2">
                    <span className="text-blue-600 font-bold text-sm">R</span>
                  </div>
                  <div className="font-semibold text-slate-900">React</div>
                </div>
                <div className="bg-green-50 p-4 rounded-lg text-center">
                  <div className="w-8 h-8 bg-green-100 rounded-lg flex items-center justify-center mx-auto mb-2">
                    <span className="text-green-600 font-bold text-sm">N</span>
                  </div>
                  <div className="font-semibold text-slate-900">Node.js</div>
                </div>
                <div className="bg-yellow-50 p-4 rounded-lg text-center">
                  <div className="w-8 h-8 bg-yellow-100 rounded-lg flex items-center justify-center mx-auto mb-2">
                    <span className="text-yellow-600 font-bold text-sm">P</span>
                  </div>
                  <div className="font-semibold text-slate-900">Python</div>
                </div>
                <div className="bg-purple-50 p-4 rounded-lg text-center">
                  <div className="w-8 h-8 bg-purple-100 rounded-lg flex items-center justify-center mx-auto mb-2">
                    <span className="text-purple-600 font-bold text-sm">M</span>
                  </div>
                  <div className="font-semibold text-slate-900">MongoDB</div>
                </div>
              </div>
              
              <div className="text-center">
                <div className="inline-flex items-center bg-green-600 text-white px-4 py-2 rounded-full text-sm font-semibold">
                  <CheckCircle className="w-4 h-4 mr-2" />
                  Full-Stack Ready
                </div>
              </div>
            </div>
          </div>
        </div>
        
        <div className="grid lg:grid-cols-2 gap-12 items-center mb-20">
          <div className="order-2 lg:order-1">
            <div className="bg-white rounded-2xl shadow-lg p-8 border border-slate-200">
              <div className="text-center mb-6">
                <div className="w-16 h-16 bg-gradient-to-r from-pink-500 to-violet-600 rounded-2xl flex items-center justify-center mx-auto mb-4">
                  <span className="text-2xl text-white">📱</span>
                </div>
                <h4 className="text-lg font-bold text-slate-900">Mobile Excellence</h4>
              </div>
              
              <div className="space-y-3">
                <div className="flex justify-between items-center p-3 bg-slate-50 rounded-lg">
                  <span className="font-medium">iOS Development</span>
                  <span className="text-green-600 font-semibold">Expert</span>
                </div>
                <div className="flex justify-between items-center p-3 bg-slate-50 rounded-lg">
                  <span className="font-medium">Android Development</span>
                  <span className="text-green-600 font-semibold">Expert</span>
                </div>
                <div className="flex justify-between items-center p-3 bg-slate-50 rounded-lg">
                  <span className="font-medium">React Native</span>
                  <span className="text-green-600 font-semibold">Expert</span>
                </div>
                <div className="flex justify-between items-center p-3 bg-slate-50 rounded-lg">
                  <span className="font-medium">Flutter</span>
                  <span className="text-green-600 font-semibold">Expert</span>
                </div>
              </div>
            </div>
          </div>
          
          <div className="order-1 lg:order-2">
            <h3 className="text-2xl font-bold text-slate-900 mb-6">Mobile App Development</h3>
            <p className="text-lg text-slate-600 mb-8">
              Create engaging mobile experiences for iOS and Android. Our developers excel in native and cross-platform development using the latest frameworks.
            </p>
            
            <div className="space-y-4 mb-8">
              <div className="flex items-center">
                <CheckCircle className="w-5 h-5 text-green-600 mr-3" />
                <span className="text-slate-700">Native iOS & Android Apps</span>
              </div>
              <div className="flex items-center">
                <CheckCircle className="w-5 h-5 text-green-600 mr-3" />
                <span className="text-slate-700">Cross-Platform Solutions</span>
              </div>
              <div className="flex items-center">
                <CheckCircle className="w-5 h-5 text-green-600 mr-3" />
                <span className="text-slate-700">UI/UX Design</span>
              </div>
              <div className="flex items-center">
                <CheckCircle className="w-5 h-5 text-green-600 mr-3" />
                <span className="text-slate-700">App Store Deployment</span>
              </div>
            </div>
            
            <Button 
              onClick={handleViewProjects}
              className="bg-primary hover:bg-blue-700 text-white px-6 py-3 rounded-lg font-semibold transition-colors"
            >
              View Projects
            </Button>
          </div>
        </div>
        
        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
          <div className="bg-white p-6 rounded-xl shadow-sm border border-slate-200 text-center">
            <div className="w-12 h-12 bg-blue-100 rounded-xl flex items-center justify-center mx-auto mb-4">
              <Brain className="w-6 h-6 text-primary" />
            </div>
            <h4 className="font-bold text-slate-900 mb-2">AI/ML Development</h4>
            <p className="text-sm text-slate-600">Advanced AI solutions and machine learning models</p>
          </div>
          
          <div className="bg-white p-6 rounded-xl shadow-sm border border-slate-200 text-center">
            <div className="w-12 h-12 bg-green-100 rounded-xl flex items-center justify-center mx-auto mb-4">
              <Cloud className="w-6 h-6 text-green-600" />
            </div>
            <h4 className="font-bold text-slate-900 mb-2">Cloud Solutions</h4>
            <p className="text-sm text-slate-600">AWS, Azure, and GCP deployment & management</p>
          </div>
          
          <div className="bg-white p-6 rounded-xl shadow-sm border border-slate-200 text-center">
            <div className="w-12 h-12 bg-purple-100 rounded-xl flex items-center justify-center mx-auto mb-4">
              <Shield className="w-6 h-6 text-purple-600" />
            </div>
            <h4 className="font-bold text-slate-900 mb-2">DevOps & Security</h4>
            <p className="text-sm text-slate-600">CI/CD pipelines and security implementation</p>
          </div>
          
          <div className="bg-white p-6 rounded-xl shadow-sm border border-slate-200 text-center">
            <div className="w-12 h-12 bg-orange-100 rounded-xl flex items-center justify-center mx-auto mb-4">
              <BarChart className="w-6 h-6 text-orange-600" />
            </div>
            <h4 className="font-bold text-slate-900 mb-2">Data Analytics</h4>
            <p className="text-sm text-slate-600">Business intelligence and data visualization</p>
          </div>
        </div>
      </div>
    </section>
  );
}
