import { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { ChevronLeft, ChevronRight, TrendingUp, Clock, Users, Award, ArrowUpRight } from 'lucide-react';
import { useLanguage } from '@/lib/i18n';

interface CaseStudy {
  id: number;
  title: string;
  client: string;
  industry: string;
  location: string;
  challenge: string;
  solution: string;
  results: {
    metric: string;
    value: string;
    description: string;
  }[];
  technologies: string[];
  teamSize: number;
  duration: string;
  savings: string;
  testimonial: {
    quote: string;
    author: string;
    title: string;
  };
}

export default function CaseStudies() {
  const [activeCase, setActiveCase] = useState(0);
  const { t } = useLanguage();

  const caseStudies: CaseStudy[] = [
    {
      id: 1,
      title: "Digital Banking Platform Transformation",
      client: "Tokyo Financial Services",
      industry: "Fintech",
      location: "Tokyo, Japan",
      challenge: "A leading Japanese financial institution needed to build a comprehensive digital banking platform to compete with emerging fintech startups. They required a team capable of handling complex financial regulations while delivering a modern user experience.",
      solution: "We assembled a specialized team of 8 engineers with expertise in fintech, security, and mobile development. Our engineers worked directly with the client's in-house team, following Japanese banking regulations and implementing advanced security protocols.",
      results: [
        { metric: "Development Time", value: "40% Faster", description: "Reduced from 18 to 11 months" },
        { metric: "Cost Savings", value: "65%", description: "Compared to local hiring" },
        { metric: "User Adoption", value: "500K+", description: "Active users in first 6 months" },
        { metric: "Security Score", value: "99.9%", description: "Compliance rating achieved" }
      ],
      technologies: ["React Native", "Node.js", "AWS", "MongoDB", "Kubernetes", "TypeScript"],
      teamSize: 8,
      duration: "11 months",
      savings: "¥120M",
      testimonial: {
        quote: "Tech Japan's engineers didn't just deliver code; they understood our business culture and regulatory requirements. The result exceeded our expectations in both quality and timeline.",
        author: "Takeshi Yamamoto",
        title: "CTO, Tokyo Financial Services"
      }
    },
    {
      id: 2,
      title: "E-commerce Platform Scaling",
      client: "Seoul Commerce Group",
      industry: "E-commerce",
      location: "Seoul, South Korea",
      challenge: "A rapidly growing Korean e-commerce company faced performance issues with their platform during peak shopping seasons. They needed to rebuild their architecture to handle 10x traffic growth while maintaining sub-second response times.",
      solution: "Our team of 12 engineers implemented a microservices architecture with advanced caching and auto-scaling capabilities. We worked in Korean business hours and integrated seamlessly with their existing development processes.",
      results: [
        { metric: "Performance", value: "300% Improvement", description: "Page load times reduced to 0.8s" },
        { metric: "Scalability", value: "10x Traffic", description: "Handles peak loads seamlessly" },
        { metric: "Uptime", value: "99.99%", description: "Zero downtime during launch" },
        { metric: "Revenue Impact", value: "+150%", description: "Increased sales capacity" }
      ],
      technologies: ["React", "Python", "Django", "Redis", "PostgreSQL", "Docker", "AWS"],
      teamSize: 12,
      duration: "8 months",
      savings: "₩2.4B",
      testimonial: {
        quote: "The team's expertise in scaling e-commerce platforms was evident from day one. They transformed our infrastructure and enabled us to handle our busiest shopping season without any issues.",
        author: "Sarah Kim",
        title: "Head of Engineering, Seoul Commerce Group"
      }
    },
    {
      id: 3,
      title: "AI-Powered Manufacturing Optimization",
      client: "Singapore Manufacturing Corp",
      industry: "Manufacturing",
      location: "Singapore",
      challenge: "A manufacturing company wanted to implement AI-driven predictive maintenance and quality control systems. They lacked the specialized AI/ML expertise needed to build these systems from scratch.",
      solution: "We provided a team of 6 AI/ML specialists who developed computer vision models for quality inspection and predictive algorithms for equipment maintenance. The solution integrated with existing IoT sensors and manufacturing systems.",
      results: [
        { metric: "Defect Reduction", value: "85%", description: "Automated quality detection" },
        { metric: "Downtime Prevention", value: "92%", description: "Predictive maintenance accuracy" },
        { metric: "Cost Reduction", value: "₹180M", description: "Annual operational savings" },
        { metric: "ROI", value: "340%", description: "Return on investment achieved" }
      ],
      technologies: ["Python", "TensorFlow", "OpenCV", "AWS SageMaker", "IoT", "Apache Kafka"],
      teamSize: 6,
      duration: "10 months",
      savings: "S$2.8M",
      testimonial: {
        quote: "The AI expertise provided by Tech Japan transformed our manufacturing processes. We now prevent issues before they occur and maintain consistent quality standards.",
        author: "Chen Wei",
        title: "Innovation Director, Singapore Manufacturing Corp"
      }
    }
  ];

  const currentCase = caseStudies[activeCase];

  const nextCase = () => {
    setActiveCase((prev) => (prev + 1) % caseStudies.length);
  };

  const prevCase = () => {
    setActiveCase((prev) => (prev - 1 + caseStudies.length) % caseStudies.length);
  };

  return (
    <div className="bg-slate-50 py-16" id="case-studies">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-12">
          <div className="inline-flex items-center bg-primary/10 text-primary px-4 py-2 rounded-full text-sm font-medium mb-4">
            <Award className="w-4 h-4 mr-2" />
            Proven Success Stories
          </div>
          <h2 className="text-4xl font-bold text-slate-900 mb-4">
            Real Results from Real Clients
          </h2>
          <p className="text-xl text-slate-600 max-w-3xl mx-auto">
            Discover how leading Asian companies have transformed their development capabilities 
            and achieved remarkable outcomes with our engineering talent
          </p>
        </div>

        <div className="relative">
          <Card className="border-0 shadow-2xl overflow-hidden">
            {/* Header */}
            <div className="bg-gradient-to-r from-primary to-blue-600 p-8 text-white">
              <div className="flex items-start justify-between mb-6">
                <div>
                  <div className="flex items-center space-x-4 mb-4">
                    <Badge className="bg-white/20 text-white">{currentCase.industry}</Badge>
                    <span className="text-blue-100">{currentCase.location}</span>
                  </div>
                  <h3 className="text-3xl font-bold mb-2">{currentCase.title}</h3>
                  <p className="text-xl text-blue-100">{currentCase.client}</p>
                </div>
                <div className="text-right">
                  <div className="text-2xl font-bold">{currentCase.savings}</div>
                  <div className="text-blue-100 text-sm">Total Savings</div>
                </div>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <div className="bg-white/10 rounded-lg p-4 text-center">
                  <Users className="w-6 h-6 mx-auto mb-2" />
                  <div className="text-xl font-bold">{currentCase.teamSize}</div>
                  <div className="text-blue-100 text-sm">Engineers</div>
                </div>
                <div className="bg-white/10 rounded-lg p-4 text-center">
                  <Clock className="w-6 h-6 mx-auto mb-2" />
                  <div className="text-xl font-bold">{currentCase.duration}</div>
                  <div className="text-blue-100 text-sm">Timeline</div>
                </div>
                <div className="bg-white/10 rounded-lg p-4 text-center">
                  <TrendingUp className="w-6 h-6 mx-auto mb-2" />
                  <div className="text-xl font-bold">65%</div>
                  <div className="text-blue-100 text-sm">Cost Reduction</div>
                </div>
              </div>
            </div>

            <CardContent className="p-8">
              <div className="grid lg:grid-cols-2 gap-8">
                {/* Challenge & Solution */}
                <div className="space-y-6">
                  <div>
                    <h4 className="text-xl font-semibold text-slate-900 mb-3">The Challenge</h4>
                    <p className="text-slate-600 leading-relaxed">{currentCase.challenge}</p>
                  </div>
                  
                  <div>
                    <h4 className="text-xl font-semibold text-slate-900 mb-3">Our Solution</h4>
                    <p className="text-slate-600 leading-relaxed">{currentCase.solution}</p>
                  </div>

                  <div>
                    <h4 className="text-xl font-semibold text-slate-900 mb-3">Technologies Used</h4>
                    <div className="flex flex-wrap gap-2">
                      {currentCase.technologies.map((tech, index) => (
                        <Badge key={index} variant="outline" className="text-sm">
                          {tech}
                        </Badge>
                      ))}
                    </div>
                  </div>
                </div>

                {/* Results */}
                <div>
                  <h4 className="text-xl font-semibold text-slate-900 mb-6">Key Results</h4>
                  <div className="grid grid-cols-2 gap-4 mb-6">
                    {currentCase.results.map((result, index) => (
                      <Card key={index} className="border border-slate-200">
                        <CardContent className="p-4 text-center">
                          <div className="text-2xl font-bold text-primary mb-1">
                            {result.value}
                          </div>
                          <div className="text-sm font-medium text-slate-900 mb-1">
                            {result.metric}
                          </div>
                          <div className="text-xs text-slate-500">
                            {result.description}
                          </div>
                        </CardContent>
                      </Card>
                    ))}
                  </div>

                  {/* Testimonial */}
                  <Card className="bg-gradient-to-br from-blue-50 to-indigo-50 border-l-4 border-l-primary">
                    <CardContent className="p-6">
                      <p className="text-slate-700 italic mb-4 leading-relaxed">
                        "{currentCase.testimonial.quote}"
                      </p>
                      <div className="flex items-center">
                        <div className="w-12 h-12 bg-primary rounded-full flex items-center justify-center text-white font-bold mr-4">
                          {currentCase.testimonial.author.split(' ').map(n => n[0]).join('')}
                        </div>
                        <div>
                          <div className="font-semibold text-slate-900">
                            {currentCase.testimonial.author}
                          </div>
                          <div className="text-slate-600 text-sm">
                            {currentCase.testimonial.title}
                          </div>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Navigation */}
          <div className="flex justify-center items-center mt-8 space-x-4">
            <Button
              variant="outline"
              size="sm"
              onClick={prevCase}
              className="p-3"
            >
              <ChevronLeft className="w-4 h-4" />
            </Button>
            
            <div className="flex space-x-2">
              {caseStudies.map((_, index) => (
                <button
                  key={index}
                  onClick={() => setActiveCase(index)}
                  className={`w-3 h-3 rounded-full transition-colors ${
                    index === activeCase ? 'bg-primary' : 'bg-slate-300'
                  }`}
                />
              ))}
            </div>

            <Button
              variant="outline"
              size="sm"
              onClick={nextCase}
              className="p-3"
            >
              <ChevronRight className="w-4 h-4" />
            </Button>
          </div>
        </div>

        {/* CTA Section */}
        <div className="text-center mt-12">
          <h3 className="text-2xl font-bold text-slate-900 mb-4">
            Ready to Create Your Success Story?
          </h3>
          <p className="text-slate-600 mb-6">
            Join these industry leaders who transformed their development capabilities
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Button className="bg-primary hover:bg-blue-700 px-8 py-3">
              Schedule a Consultation
              <ArrowUpRight className="w-4 h-4 ml-2" />
            </Button>
            <Button variant="outline" className="px-8 py-3">
              Request a Demo
            </Button>
          </div>
        </div>
      </div>
    </div>
  );
}