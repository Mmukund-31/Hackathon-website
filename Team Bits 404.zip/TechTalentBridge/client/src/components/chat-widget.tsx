import { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { MessageCircle, X, Send, Clock, Users, Award } from 'lucide-react';
import { useLanguage } from '@/lib/i18n';

export default function ChatWidget() {
  const [isOpen, setIsOpen] = useState(false);
  const [message, setMessage] = useState('');
  const [isOnline, setIsOnline] = useState(true);
  const { t } = useLanguage();

  const quickActions = [
    { icon: Clock, text: 'Schedule Consultation', action: 'schedule' },
    { icon: Users, text: 'View Engineers', action: 'engineers' },
    { icon: Award, text: 'Success Stories', action: 'success' }
  ];

  const handleSendMessage = () => {
    if (message.trim()) {
      // In a real implementation, this would send to a chat service
      console.log('Sending message:', message);
      setMessage('');
    }
  };

  if (!isOpen) {
    return (
      <div className="fixed bottom-6 right-6 z-50">
        <Button
          onClick={() => setIsOpen(true)}
          className="bg-primary hover:bg-blue-700 text-white rounded-full p-4 shadow-lg relative"
        >
          <MessageCircle className="h-6 w-6" />
          {isOnline && (
            <div className="absolute -top-1 -right-1 w-3 h-3 bg-green-500 rounded-full border-2 border-white"></div>
          )}
        </Button>
      </div>
    );
  }

  return (
    <div className="fixed bottom-6 right-6 z-50 w-80 h-96">
      <Card className="h-full flex flex-col shadow-xl">
        <CardHeader className="bg-primary text-white rounded-t-lg p-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-2">
              <div className="w-8 h-8 bg-white/20 rounded-full flex items-center justify-center">
                <MessageCircle className="h-4 w-4" />
              </div>
              <div>
                <CardTitle className="text-sm">Tech Japan Support</CardTitle>
                <div className="flex items-center text-xs text-blue-100">
                  <div className="w-2 h-2 bg-green-400 rounded-full mr-1"></div>
                  Online - Avg response: 2 min
                </div>
              </div>
            </div>
            <Button
              variant="ghost"
              size="sm"
              onClick={() => setIsOpen(false)}
              className="text-white hover:bg-white/20"
            >
              <X className="h-4 w-4" />
            </Button>
          </div>
        </CardHeader>

        <CardContent className="flex-1 p-4 flex flex-col">
          <div className="flex-1 mb-4">
            <div className="bg-slate-100 rounded-lg p-3 mb-3 text-sm">
              <p className="font-medium text-primary mb-1">Welcome! 👋</p>
              <p className="text-slate-600">
                How can we help you find the perfect Indian engineers for your project?
              </p>
            </div>

            <div className="space-y-2">
              <p className="text-xs text-slate-500 font-medium">Quick Actions:</p>
              {quickActions.map((action, index) => (
                <button
                  key={index}
                  className="w-full text-left p-2 rounded-lg border border-slate-200 hover:bg-slate-50 transition-colors flex items-center space-x-2 text-sm"
                  onClick={() => {
                    if (action.action === 'schedule') {
                      document.getElementById('contact')?.scrollIntoView({ behavior: 'smooth' });
                    } else if (action.action === 'engineers') {
                      window.location.href = '/client-portal';
                    } else if (action.action === 'success') {
                      document.getElementById('success')?.scrollIntoView({ behavior: 'smooth' });
                    }
                  }}
                >
                  <action.icon className="h-4 w-4 text-primary" />
                  <span>{action.text}</span>
                </button>
              ))}
            </div>
          </div>

          <div className="border-t pt-3">
            <div className="flex space-x-2">
              <Textarea
                placeholder="Type your message..."
                value={message}
                onChange={(e) => setMessage(e.target.value)}
                className="flex-1 min-h-[60px] text-sm"
                onKeyPress={(e) => {
                  if (e.key === 'Enter' && !e.shiftKey) {
                    e.preventDefault();
                    handleSendMessage();
                  }
                }}
              />
              <Button
                onClick={handleSendMessage}
                size="sm"
                className="bg-primary hover:bg-blue-700"
                disabled={!message.trim()}
              >
                <Send className="h-4 w-4" />
              </Button>
            </div>
            <p className="text-xs text-slate-500 mt-2">
              Available 24/7 • Response within 2 minutes
            </p>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}