import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { insertContactSubmissionSchema } from "@shared/schema";
import type { InsertContactSubmission } from "@shared/schema";
import { useMutation } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { CheckCircle, Mail, Phone, MapPin, Send, Clock, Users, Zap } from "lucide-react";

export default function Contact() {
  const { toast } = useToast();
  const [isSubmitting, setIsSubmitting] = useState(false);

  const {
    register,
    handleSubmit,
    setValue,
    watch,
    reset,
    formState: { errors }
  } = useForm<InsertContactSubmission>({
    resolver: zodResolver(insertContactSubmissionSchema),
    defaultValues: {
      companyName: "",
      firstName: "",
      lastName: "",
      email: "",
      phone: "",
      engineerType: "",
      projectDetails: ""
    }
  });

  const contactMutation = useMutation({
    mutationFn: async (data: InsertContactSubmission) => {
      const response = await apiRequest("POST", "/api/contact", data);
      return response.json();
    },
    onSuccess: (data) => {
      toast({
        title: "Success!",
        description: data.message || "We'll get back to you within 48 hours!",
      });
      reset();
      setIsSubmitting(false);
    },
    onError: (error: any) => {
      toast({
        title: "Error",
        description: error.message || "Something went wrong. Please try again.",
        variant: "destructive",
      });
      setIsSubmitting(false);
    }
  });

  const onSubmit = (data: InsertContactSubmission) => {
    setIsSubmitting(true);
    contactMutation.mutate(data);
  };

  const watchedEngineerType = watch("engineerType");

  return (
    <section id="contact" className="py-20 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <div className="inline-flex items-center bg-gradient-to-r from-orange-100 to-red-100 text-orange-800 px-6 py-3 rounded-full text-lg font-bold mb-6 border border-orange-200">
            <Send className="w-5 h-5 mr-2" />
            Start Your Project Today
          </div>
          <h2 className="text-4xl lg:text-6xl font-bold text-slate-900 mb-8 leading-tight">
            <span className="block text-3xl lg:text-4xl text-slate-600 mb-2">Ready to Build Something Amazing?</span>
            <span className="bg-gradient-to-r from-primary to-purple-600 bg-clip-text text-transparent">
              Let's Connect You with Top Talent
            </span>
          </h2>
          <div className="max-w-4xl mx-auto mb-8">
            <p className="text-2xl text-slate-700 font-semibold mb-4">
              48-hour matching. Zero risk. Immediate impact.
            </p>
            <p className="text-xl text-slate-600">
              Tell us about your project and we'll match you with the perfect engineers from our vetted talent pool. Start building your dream team today.
            </p>
          </div>
          
          <div className="flex flex-wrap justify-center gap-6 text-lg">
            <div className="flex items-center text-green-700 bg-green-50 px-4 py-2 rounded-full border border-green-200">
              <CheckCircle className="w-5 h-5 mr-2" />
              <span className="font-semibold">Free Consultation</span>
            </div>
            <div className="flex items-center text-blue-700 bg-blue-50 px-4 py-2 rounded-full border border-blue-200">
              <Clock className="w-5 h-5 mr-2" />
              <span className="font-semibold">48-Hour Response</span>
            </div>
            <div className="flex items-center text-purple-700 bg-purple-50 px-4 py-2 rounded-full border border-purple-200">
              <Users className="w-5 h-5 mr-2" />
              <span className="font-semibold">Pre-Vetted Talent</span>
            </div>
          </div>
        </div>
        
        <div className="grid lg:grid-cols-2 gap-12 items-start">
          <div>
            <div className="bg-slate-50 rounded-2xl p-8 mb-8">
              <h3 className="text-xl font-bold text-slate-900 mb-6">Why Choose Tech Japan?</h3>
              
              <div className="space-y-4">
                <div className="flex items-start">
                  <CheckCircle className="w-5 h-5 text-green-600 mr-3 mt-1" />
                  <div>
                    <div className="font-semibold text-slate-900">Pre-Vetted Talent</div>
                    <div className="text-sm text-slate-600">All engineers pass rigorous technical and communication assessments</div>
                  </div>
                </div>
                
                <div className="flex items-start">
                  <CheckCircle className="w-5 h-5 text-green-600 mr-3 mt-1" />
                  <div>
                    <div className="font-semibold text-slate-900">Fast Matching</div>
                    <div className="text-sm text-slate-600">Get matched with qualified candidates within 48 hours</div>
                  </div>
                </div>
                
                <div className="flex items-start">
                  <CheckCircle className="w-5 h-5 text-green-600 mr-3 mt-1" />
                  <div>
                    <div className="font-semibold text-slate-900">Cost Effective</div>
                    <div className="text-sm text-slate-600">Save up to 60% on development costs without compromising quality</div>
                  </div>
                </div>
                
                <div className="flex items-start">
                  <CheckCircle className="w-5 h-5 text-green-600 mr-3 mt-1" />
                  <div>
                    <div className="font-semibold text-slate-900">Ongoing Support</div>
                    <div className="text-sm text-slate-600">Dedicated account management and project support</div>
                  </div>
                </div>
              </div>
            </div>
            
            <div className="space-y-6">
              <div className="flex items-center">
                <div className="w-12 h-12 bg-blue-100 rounded-xl flex items-center justify-center mr-4">
                  <Mail className="w-6 h-6 text-primary" />
                </div>
                <div>
                  <div className="font-semibold text-slate-900">Email</div>
                  <div className="text-slate-600">hello@techjapan.com</div>
                </div>
              </div>
              
              <div className="flex items-center">
                <div className="w-12 h-12 bg-green-100 rounded-xl flex items-center justify-center mr-4">
                  <Phone className="w-6 h-6 text-green-600" />
                </div>
                <div>
                  <div className="font-semibold text-slate-900">Phone</div>
                  <div className="text-slate-600">+81-3-1234-5678</div>
                </div>
              </div>
              
              <div className="flex items-center">
                <div className="w-12 h-12 bg-purple-100 rounded-xl flex items-center justify-center mr-4">
                  <MapPin className="w-6 h-6 text-purple-600" />
                </div>
                <div>
                  <div className="font-semibold text-slate-900">Office</div>
                  <div className="text-slate-600">Tokyo, Japan</div>
                </div>
              </div>
            </div>
          </div>
          
          <div className="bg-gradient-to-br from-white to-blue-50/30 border-2 border-primary/20 rounded-2xl shadow-2xl p-8 relative overflow-hidden">
            <div className="absolute top-0 right-0 w-32 h-32 bg-gradient-to-br from-primary/10 to-purple-500/10 rounded-full blur-3xl"></div>
            <div className="relative">
              <div className="flex items-center mb-6">
                <div className="w-12 h-12 bg-gradient-to-r from-primary to-blue-700 rounded-xl flex items-center justify-center mr-4">
                  <Zap className="w-6 h-6 text-white" />
                </div>
                <div>
                  <h3 className="text-2xl font-bold text-slate-900">Start Your Project</h3>
                  <p className="text-slate-600">Get matched in 48 hours</p>
                </div>
              </div>
            
              <form onSubmit={handleSubmit(onSubmit)} className="space-y-6">
                <div>
                  <Label htmlFor="companyName" className="block text-sm font-semibold text-slate-900 mb-2">
                    Company Name *
                  </Label>
                  <Input
                    id="companyName"
                    {...register("companyName")}
                    placeholder="Your company name"
                    className="w-full"
                  />
                  {errors.companyName && (
                    <p className="text-red-600 text-sm mt-1">{errors.companyName.message}</p>
                  )}
                </div>
                
                <div className="grid md:grid-cols-2 gap-4">
                  <div>
                    <Label htmlFor="firstName" className="block text-sm font-semibold text-slate-900 mb-2">
                      First Name *
                    </Label>
                    <Input
                      id="firstName"
                      {...register("firstName")}
                      placeholder="John"
                      className="w-full"
                    />
                    {errors.firstName && (
                      <p className="text-red-600 text-sm mt-1">{errors.firstName.message}</p>
                    )}
                  </div>
                  <div>
                    <Label htmlFor="lastName" className="block text-sm font-semibold text-slate-900 mb-2">
                      Last Name *
                    </Label>
                    <Input
                      id="lastName"
                      {...register("lastName")}
                      placeholder="Doe"
                      className="w-full"
                    />
                    {errors.lastName && (
                      <p className="text-red-600 text-sm mt-1">{errors.lastName.message}</p>
                    )}
                  </div>
                </div>
                
                <div>
                  <Label htmlFor="email" className="block text-sm font-semibold text-slate-900 mb-2">
                    Business Email *
                  </Label>
                  <Input
                    id="email"
                    type="email"
                    {...register("email")}
                    placeholder="john@company.com"
                    className="w-full"
                  />
                  {errors.email && (
                    <p className="text-red-600 text-sm mt-1">{errors.email.message}</p>
                  )}
                </div>
                
                <div>
                  <Label htmlFor="phone" className="block text-sm font-semibold text-slate-900 mb-2">
                    Phone Number
                  </Label>
                  <Input
                    id="phone"
                    type="tel"
                    {...register("phone")}
                    placeholder="+81 XX XXXX XXXX"
                    className="w-full"
                  />
                </div>
                
                <div>
                  <Label htmlFor="engineerType" className="block text-sm font-semibold text-slate-900 mb-2">
                    What type of engineers do you need?
                  </Label>
                  <Select
                    value={watchedEngineerType || ""}
                    onValueChange={(value) => setValue("engineerType", value)}
                  >
                    <SelectTrigger className="w-full">
                      <SelectValue placeholder="Select engineer type" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="fullstack">Full-Stack Developers</SelectItem>
                      <SelectItem value="frontend">Frontend Developers</SelectItem>
                      <SelectItem value="backend">Backend Developers</SelectItem>
                      <SelectItem value="mobile">Mobile App Developers</SelectItem>
                      <SelectItem value="aiml">AI/ML Engineers</SelectItem>
                      <SelectItem value="devops">DevOps Engineers</SelectItem>
                      <SelectItem value="other">Other</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                
                <div>
                  <Label htmlFor="projectDetails" className="block text-sm font-semibold text-slate-900 mb-2">
                    Project Details
                  </Label>
                  <Textarea
                    id="projectDetails"
                    {...register("projectDetails")}
                    rows={4}
                    placeholder="Tell us about your project, timeline, and requirements..."
                    className="w-full resize-none"
                  />
                </div>
                
                <Button 
                  type="submit" 
                  disabled={isSubmitting}
                  className="w-full bg-gradient-to-r from-primary to-blue-700 hover:from-blue-700 hover:to-primary text-white px-6 py-4 rounded-lg font-bold text-lg transition-all duration-300 shadow-lg hover:shadow-xl transform hover:-translate-y-1"
                >
                  {isSubmitting ? (
                    <>Please wait...</>
                  ) : (
                    <>
                      <Send className="w-5 h-5 mr-2" />
                      Get Matched with Engineers Now
                    </>
                  )}
                </Button>
                
                <p className="text-xs text-slate-500 text-center">
                  By submitting this form, you agree to our Terms of Service and Privacy Policy. We'll connect you with qualified engineers within 48 hours.
                </p>
              </form>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}