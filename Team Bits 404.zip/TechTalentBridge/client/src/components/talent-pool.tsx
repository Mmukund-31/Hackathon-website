import { Badge } from "@/components/ui/badge";
import { CheckCircle } from "lucide-react";

export default function TalentPool() {
  const engineers = [
    {
      name: "Rajesh Kumar",
      role: "Senior Full-Stack Developer",
      initial: "R",
      gradient: "from-blue-500 to-purple-600",
      skills: ["React", "Node.js", "AWS"],
      experience: "8+ years experience"
    },
    {
      name: "Priya Sharma",
      role: "Mobile App Specialist",
      initial: "P",
      gradient: "from-green-500 to-teal-600",
      skills: ["Flutter", "React Native", "iOS"],
      experience: "6+ years experience"
    },
    {
      name: "Arjun Patel",
      role: "AI/ML Engineer",
      initial: "A",
      gradient: "from-orange-500 to-red-600",
      skills: ["Python", "TensorFlow", "PyTorch"],
      experience: "7+ years experience"
    },
    {
      name: "Sneha Gupta",
      role: "DevOps Engineer",
      initial: "S",
      gradient: "from-pink-500 to-violet-600",
      skills: ["Docker", "Kubernetes", "Jenkins"],
      experience: "5+ years experience"
    }
  ];

  const skillCategories = [
    {
      category: "Frontend",
      icon: "💻",
      count: "2,340+ Engineers",
      skills: "React, Vue, Angular, TypeScript",
      bgColor: "bg-blue-100"
    },
    {
      category: "Backend",
      icon: "🔧",
      count: "1,890+ Engineers",
      skills: "Node.js, Python, Java, .NET",
      bgColor: "bg-green-100"
    },
    {
      category: "Mobile",
      icon: "📱",
      count: "1,560+ Engineers",
      skills: "iOS, Android, React Native, Flutter",
      bgColor: "bg-purple-100"
    },
    {
      category: "AI/ML",
      icon: "🧠",
      count: "780+ Engineers",
      skills: "Python, TensorFlow, PyTorch, Data Science",
      bgColor: "bg-orange-100"
    }
  ];

  const vettingSteps = [
    {
      step: 1,
      title: "Technical Assessment",
      description: "Comprehensive coding tests and problem-solving challenges"
    },
    {
      step: 2,
      title: "Portfolio Review",
      description: "In-depth analysis of previous projects and code quality"
    },
    {
      step: 3,
      title: "Communication Skills",
      description: "English proficiency and collaboration capability assessment"
    },
    {
      step: 4,
      title: "Final Approval",
      description: "Cultural fit and long-term commitment evaluation",
      isComplete: true
    }
  ];

  return (
    <section id="talent" className="py-20 bg-slate-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="text-3xl lg:text-5xl font-bold text-slate-900 mb-6">
            Meet Our <span className="text-primary">Elite Engineers</span>
          </h2>
          <p className="text-xl text-slate-600 max-w-3xl mx-auto">
            Every engineer in our network has been rigorously vetted through technical assessments, portfolio reviews, and communication evaluations.
          </p>
        </div>
        
        <div className="grid lg:grid-cols-2 gap-12 items-center mb-16">
          <div>
            <h3 className="text-2xl font-bold text-slate-900 mb-6">Rigorous Vetting Process</h3>
            <p className="text-lg text-slate-600 mb-8">
              Only the top 3% of applicants make it through our comprehensive screening process, ensuring you work with the best talent available.
            </p>
            
            <div className="space-y-6">
              {vettingSteps.map((step, index) => (
                <div key={index} className="flex items-start">
                  <div className={`w-8 h-8 ${step.isComplete ? 'bg-green-600' : 'bg-primary'} rounded-full flex items-center justify-center flex-shrink-0 mr-4 mt-1`}>
                    {step.isComplete ? (
                      <CheckCircle className="w-4 h-4 text-white" />
                    ) : (
                      <span className="text-white font-bold text-sm">{step.step}</span>
                    )}
                  </div>
                  <div>
                    <h4 className="font-bold text-slate-900 mb-2">{step.title}</h4>
                    <p className="text-slate-600">{step.description}</p>
                  </div>
                </div>
              ))}
            </div>
          </div>
          
          <div className="grid grid-cols-2 gap-6">
            {engineers.map((engineer, index) => (
              <div key={index} className="bg-white p-6 rounded-xl shadow-sm border border-slate-200">
                <div className={`w-16 h-16 bg-gradient-to-r ${engineer.gradient} rounded-full flex items-center justify-center mx-auto mb-4`}>
                  <span className="text-white font-bold text-xl">{engineer.initial}</span>
                </div>
                <div className="text-center">
                  <h4 className="font-bold text-slate-900 mb-1">{engineer.name}</h4>
                  <p className="text-sm text-slate-500 mb-3">{engineer.role}</p>
                  <div className="flex flex-wrap gap-1 justify-center mb-3">
                    {engineer.skills.map((skill, skillIndex) => (
                      <Badge key={skillIndex} variant="secondary" className="text-xs">
                        {skill}
                      </Badge>
                    ))}
                  </div>
                  <p className="text-xs text-slate-600">{engineer.experience}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
        
        <div className="bg-white rounded-2xl p-8 shadow-sm border border-slate-200">
          <h3 className="text-2xl font-bold text-slate-900 mb-8 text-center">Available Skills Distribution</h3>
          
          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
            {skillCategories.map((category, index) => (
              <div key={index} className="text-center">
                <div className={`w-20 h-20 ${category.bgColor} rounded-full flex items-center justify-center mx-auto mb-4`}>
                  <span className="text-3xl">{category.icon}</span>
                </div>
                <h4 className="font-bold text-slate-900 mb-2">{category.category}</h4>
                <p className="text-sm text-slate-600 mb-2">{category.count}</p>
                <div className="text-xs text-slate-500">{category.skills}</div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}
