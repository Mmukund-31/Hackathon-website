import { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Slider } from '@/components/ui/slider';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Badge } from '@/components/ui/badge';
import { Calculator, TrendingDown, Clock, Users } from 'lucide-react';
import { useLanguage } from '@/lib/i18n';

interface PricingData {
  currency: string;
  symbol: string;
  localRate: number;
  indiaRate: number;
  savings: number;
}

const currencyData: Record<string, PricingData> = {
  'JPY': { currency: 'JPY', symbol: '¥', localRate: 8000, indiaRate: 3200, savings: 60 },
  'KRW': { currency: 'KRW', symbol: '₩', localRate: 80000, indiaRate: 32000, savings: 60 },
  'CNY': { currency: 'CNY', symbol: '¥', localRate: 600, indiaRate: 240, savings: 60 },
  'USD': { currency: 'USD', symbol: '$', localRate: 120, indiaRate: 48, savings: 60 }
};

const skillLevels = {
  'junior': { multiplier: 0.7, label: 'Junior (1-3 years)' },
  'mid': { multiplier: 1.0, label: 'Mid-level (3-6 years)' },
  'senior': { multiplier: 1.4, label: 'Senior (6+ years)' },
  'lead': { multiplier: 1.8, label: 'Tech Lead/Architect' }
};

const projectTypes = {
  'web': { multiplier: 1.0, label: 'Web Development' },
  'mobile': { multiplier: 1.2, label: 'Mobile App Development' },
  'ai': { multiplier: 1.5, label: 'AI/ML Development' },
  'blockchain': { multiplier: 1.6, label: 'Blockchain Development' },
  'devops': { multiplier: 1.3, label: 'DevOps/Infrastructure' }
};

export default function PricingCalculator() {
  const [engineers, setEngineers] = useState([3]);
  const [duration, setDuration] = useState([6]);
  const [currency, setCurrency] = useState('USD');
  const [skillLevel, setSkillLevel] = useState('mid');
  const [projectType, setProjectType] = useState('web');
  const { t } = useLanguage();

  const currentData = currencyData[currency];
  const skillMultiplier = skillLevels[skillLevel as keyof typeof skillLevels].multiplier;
  const projectMultiplier = projectTypes[projectType as keyof typeof projectTypes].multiplier;

  const baseIndiaRate = currentData.indiaRate * skillMultiplier * projectMultiplier;
  const baseLocalRate = currentData.localRate * skillMultiplier * projectMultiplier;

  const monthlyIndiaTotal = baseIndiaRate * engineers[0];
  const monthlyLocalTotal = baseLocalRate * engineers[0];
  const totalIndiasCost = monthlyIndiaTotal * duration[0];
  const totalLocalCost = monthlyLocalTotal * duration[0];
  const totalSavings = totalLocalCost - totalIndiasCost;
  const savingsPercentage = Math.round((totalSavings / totalLocalCost) * 100);

  return (
    <div className="bg-gradient-to-br from-blue-50 to-indigo-50 py-16" id="pricing">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-12">
          <div className="inline-flex items-center bg-primary/10 text-primary px-4 py-2 rounded-full text-sm font-medium mb-4">
            <Calculator className="w-4 h-4 mr-2" />
            ROI Calculator
          </div>
          <h2 className="text-4xl font-bold text-slate-900 mb-4">
            Calculate Your Savings
          </h2>
          <p className="text-xl text-slate-600 max-w-3xl mx-auto">
            See exactly how much you'll save by hiring Indian engineers through Tech Japan
          </p>
        </div>

        <div className="grid lg:grid-cols-2 gap-8">
          {/* Calculator Inputs */}
          <Card className="border-0 shadow-lg">
            <CardHeader className="bg-white">
              <CardTitle className="text-xl text-slate-900">Project Requirements</CardTitle>
            </CardHeader>
            <CardContent className="space-y-6 bg-white">
              <div>
                <label className="block text-sm font-medium text-slate-700 mb-3">
                  Currency & Region
                </label>
                <Select value={currency} onValueChange={setCurrency}>
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="JPY">🇯🇵 Japan (JPY)</SelectItem>
                    <SelectItem value="KRW">🇰🇷 South Korea (KRW)</SelectItem>
                    <SelectItem value="CNY">🇨🇳 China (CNY)</SelectItem>
                    <SelectItem value="USD">🌍 International (USD)</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div>
                <label className="block text-sm font-medium text-slate-700 mb-3">
                  Number of Engineers: {engineers[0]}
                </label>
                <Slider
                  value={engineers}
                  onValueChange={setEngineers}
                  max={20}
                  min={1}
                  step={1}
                  className="w-full"
                />
                <div className="flex justify-between text-xs text-slate-500 mt-1">
                  <span>1 engineer</span>
                  <span>20 engineers</span>
                </div>
              </div>

              <div>
                <label className="block text-sm font-medium text-slate-700 mb-3">
                  Project Duration: {duration[0]} months
                </label>
                <Slider
                  value={duration}
                  onValueChange={setDuration}
                  max={24}
                  min={1}
                  step={1}
                  className="w-full"
                />
                <div className="flex justify-between text-xs text-slate-500 mt-1">
                  <span>1 month</span>
                  <span>24 months</span>
                </div>
              </div>

              <div>
                <label className="block text-sm font-medium text-slate-700 mb-3">
                  Skill Level
                </label>
                <Select value={skillLevel} onValueChange={setSkillLevel}>
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    {Object.entries(skillLevels).map(([key, level]) => (
                      <SelectItem key={key} value={key}>{level.label}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              <div>
                <label className="block text-sm font-medium text-slate-700 mb-3">
                  Project Type
                </label>
                <Select value={projectType} onValueChange={setProjectType}>
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    {Object.entries(projectTypes).map(([key, type]) => (
                      <SelectItem key={key} value={key}>{type.label}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            </CardContent>
          </Card>

          {/* Results */}
          <div className="space-y-6">
            <Card className="border-0 shadow-lg bg-gradient-to-br from-green-50 to-emerald-50">
              <CardHeader>
                <CardTitle className="text-xl text-slate-900 flex items-center">
                  <TrendingDown className="w-5 h-5 mr-2 text-green-600" />
                  Your Savings Breakdown
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="grid grid-cols-2 gap-4">
                  <div className="bg-white rounded-lg p-4 text-center">
                    <div className="text-2xl font-bold text-red-600">
                      {currentData.symbol}{totalLocalCost.toLocaleString()}
                    </div>
                    <div className="text-sm text-slate-600">Local Hiring Cost</div>
                  </div>
                  <div className="bg-white rounded-lg p-4 text-center">
                    <div className="text-2xl font-bold text-green-600">
                      {currentData.symbol}{totalIndiasCost.toLocaleString()}
                    </div>
                    <div className="text-sm text-slate-600">Tech Japan Cost</div>
                  </div>
                </div>

                <div className="bg-gradient-to-r from-green-500 to-emerald-500 rounded-lg p-6 text-white text-center">
                  <div className="text-3xl font-bold mb-2">
                    {currentData.symbol}{totalSavings.toLocaleString()}
                  </div>
                  <div className="text-lg mb-1">Total Savings</div>
                  <Badge className="bg-white/20 text-white">
                    {savingsPercentage}% cost reduction
                  </Badge>
                </div>
              </CardContent>
            </Card>

            {/* Additional Benefits */}
            <Card className="border-0 shadow-lg">
              <CardContent className="p-6">
                <h3 className="text-lg font-semibold text-slate-900 mb-4">Additional Benefits</h3>
                <div className="space-y-3">
                  <div className="flex items-center text-sm text-slate-600">
                    <Clock className="w-4 h-4 mr-3 text-primary" />
                    48-hour engineer deployment
                  </div>
                  <div className="flex items-center text-sm text-slate-600">
                    <Users className="w-4 h-4 mr-3 text-primary" />
                    Pre-vetted and English-fluent engineers
                  </div>
                  <div className="flex items-center text-sm text-slate-600">
                    <TrendingDown className="w-4 h-4 mr-3 text-primary" />
                    No recruitment fees or overhead costs
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>

        <div className="text-center mt-8">
          <p className="text-sm text-slate-500">
            * Rates are estimated based on market averages. Actual costs may vary based on specific requirements.
          </p>
        </div>
      </div>
    </div>
  );
}