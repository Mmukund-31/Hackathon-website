import Header from "@/components/header";
import Footer from "@/components/footer";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Download, FileText, Image, Video, BarChart3, Users } from "lucide-react";
import { useLanguage } from "@/lib/i18n";

export default function Downloads() {
  const { t } = useLanguage();

  const downloadCategories = [
    {
      title: "Company Overview",
      icon: FileText,
      description: "Comprehensive information about Tech Japan and our services",
      items: [
        {
          name: "Company Profile 2024",
          description: "Complete overview of Tech Japan's services, capabilities, and achievements",
          format: "PDF",
          size: "2.3 MB",
          lastUpdated: "December 2024"
        },
        {
          name: "Service Catalog",
          description: "Detailed breakdown of all engineering services and specializations",
          format: "PDF",
          size: "1.8 MB",
          lastUpdated: "November 2024"
        },
        {
          name: "Technical Capabilities Matrix",
          description: "Overview of technical skills and expertise available in our network",
          format: "PDF",
          size: "950 KB",
          lastUpdated: "December 2024"
        }
      ]
    },
    {
      title: "Case Studies & Success Stories",
      icon: BarChart3,
      description: "Real client results and project outcomes",
      items: [
        {
          name: "Fintech Success Story",
          description: "How a Japanese startup reduced development time by 60% with our engineers",
          format: "PDF",
          size: "1.2 MB",
          lastUpdated: "November 2024"
        },
        {
          name: "E-commerce Platform Case Study",
          description: "Complete rebuild of major e-commerce platform using our development team",
          format: "PDF",
          size: "1.5 MB",
          lastUpdated: "October 2024"
        },
        {
          name: "AI/ML Implementation Guide",
          description: "Step-by-step case study of AI implementation for Korean enterprise",
          format: "PDF",
          size: "2.1 MB",
          lastUpdated: "December 2024"
        }
      ]
    },
    {
      title: "Marketing Materials",
      icon: Image,
      description: "High-quality assets for presentations and proposals",
      items: [
        {
          name: "Company Logo Pack",
          description: "High-resolution logos in various formats and color schemes",
          format: "ZIP",
          size: "15 MB",
          lastUpdated: "September 2024"
        },
        {
          name: "Presentation Template",
          description: "Professional PowerPoint template with company branding",
          format: "PPTX",
          size: "3.2 MB",
          lastUpdated: "November 2024"
        },
        {
          name: "Infographic Collection",
          description: "Visual representations of our services and benefits",
          format: "ZIP",
          size: "8.5 MB",
          lastUpdated: "October 2024"
        }
      ]
    },
    {
      title: "Video Content",
      icon: Video,
      description: "Promotional and educational video materials",
      items: [
        {
          name: "Company Introduction Video",
          description: "5-minute overview of Tech Japan and our mission",
          format: "MP4",
          size: "125 MB",
          lastUpdated: "November 2024"
        },
        {
          name: "Client Testimonial Compilation",
          description: "Collection of video testimonials from satisfied clients",
          format: "MP4",
          size: "89 MB",
          lastUpdated: "December 2024"
        },
        {
          name: "Engineer Showcase Reel",
          description: "Meet our talented engineers and see their work",
          format: "MP4",
          size: "67 MB",
          lastUpdated: "October 2024"
        }
      ]
    }
  ];

  const handleDownload = (itemName: string) => {
    // In a real implementation, this would trigger the actual download
    console.log(`Downloading: ${itemName}`);
  };

  return (
    <div className="min-h-screen bg-background">
      <Header />
      
      {/* Hero Section */}
      <div className="bg-gradient-to-br from-primary to-blue-600 text-white py-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center">
            <Download className="w-16 h-16 mx-auto mb-6 opacity-80" />
            <h1 className="text-5xl font-bold mb-6">Download Center</h1>
            <p className="text-xl text-blue-100 max-w-3xl mx-auto">
              Access comprehensive resources about Tech Japan, including company profiles, 
              case studies, and marketing materials
            </p>
          </div>
        </div>
      </div>

      {/* Download Categories */}
      <div className="py-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="space-y-12">
            {downloadCategories.map((category, categoryIndex) => (
              <div key={categoryIndex}>
                <div className="flex items-center mb-8">
                  <category.icon className="w-8 h-8 text-primary mr-4" />
                  <div>
                    <h2 className="text-3xl font-bold text-slate-900">{category.title}</h2>
                    <p className="text-slate-600 mt-2">{category.description}</p>
                  </div>
                </div>

                <div className="grid lg:grid-cols-3 gap-6">
                  {category.items.map((item, itemIndex) => (
                    <Card key={itemIndex} className="border-0 shadow-lg hover:shadow-xl transition-shadow">
                      <CardHeader className="pb-4">
                        <CardTitle className="text-lg leading-tight">{item.name}</CardTitle>
                        <p className="text-slate-600 text-sm leading-relaxed">{item.description}</p>
                      </CardHeader>
                      <CardContent>
                        <div className="flex items-center justify-between mb-4">
                          <div className="flex items-center space-x-2">
                            <Badge variant="outline">{item.format}</Badge>
                            <span className="text-sm text-slate-500">{item.size}</span>
                          </div>
                          <span className="text-xs text-slate-500">
                            Updated {item.lastUpdated}
                          </span>
                        </div>
                        
                        <Button 
                          onClick={() => handleDownload(item.name)}
                          className="w-full bg-primary hover:bg-blue-700"
                        >
                          <Download className="w-4 h-4 mr-2" />
                          Download
                        </Button>
                      </CardContent>
                    </Card>
                  ))}
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Request Custom Materials */}
      <div className="py-16 bg-slate-50">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
          <Card className="border-0 shadow-xl">
            <CardContent className="p-8 text-center">
              <Users className="w-12 h-12 text-primary mx-auto mb-6" />
              <h2 className="text-3xl font-bold text-slate-900 mb-4">
                Need Custom Materials?
              </h2>
              <p className="text-xl text-slate-600 mb-8">
                Our team can create customized presentations, proposals, and materials 
                tailored to your specific requirements and industry needs.
              </p>
              
              <div className="grid md:grid-cols-3 gap-6 mb-8">
                <div className="text-center">
                  <div className="w-12 h-12 bg-primary/10 rounded-lg flex items-center justify-center mx-auto mb-3">
                    <FileText className="w-6 h-6 text-primary" />
                  </div>
                  <h3 className="font-semibold text-slate-900 mb-2">Custom Proposals</h3>
                  <p className="text-sm text-slate-600">
                    Tailored project proposals with specific technical requirements
                  </p>
                </div>
                
                <div className="text-center">
                  <div className="w-12 h-12 bg-primary/10 rounded-lg flex items-center justify-center mx-auto mb-3">
                    <BarChart3 className="w-6 h-6 text-primary" />
                  </div>
                  <h3 className="font-semibold text-slate-900 mb-2">Industry Reports</h3>
                  <p className="text-sm text-slate-600">
                    Sector-specific analysis and engineering capability reports
                  </p>
                </div>
                
                <div className="text-center">
                  <div className="w-12 h-12 bg-primary/10 rounded-lg flex items-center justify-center mx-auto mb-3">
                    <Image className="w-6 h-6 text-primary" />
                  </div>
                  <h3 className="font-semibold text-slate-900 mb-2">Branded Materials</h3>
                  <p className="text-sm text-slate-600">
                    Co-branded presentations and marketing materials
                  </p>
                </div>
              </div>
              
              <div className="flex flex-col sm:flex-row gap-4 justify-center">
                <Button className="bg-primary hover:bg-blue-700">
                  Request Custom Materials
                </Button>
                <Button variant="outline">
                  Contact Our Team
                </Button>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>

      {/* Usage Guidelines */}
      <div className="py-16">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
          <h2 className="text-3xl font-bold text-slate-900 mb-8 text-center">Usage Guidelines</h2>
          
          <div className="grid md:grid-cols-2 gap-8">
            <Card className="border-l-4 border-l-green-500 border-t-0 border-r-0 border-b-0 shadow-lg">
              <CardContent className="p-6">
                <h3 className="text-lg font-semibold text-slate-900 mb-4">✓ Permitted Uses</h3>
                <ul className="space-y-2 text-slate-600">
                  <li>• Internal presentations and proposals</li>
                  <li>• Client meetings and consultations</li>
                  <li>• Educational and training purposes</li>
                  <li>• Partner and stakeholder communications</li>
                </ul>
              </CardContent>
            </Card>
            
            <Card className="border-l-4 border-l-red-500 border-t-0 border-r-0 border-b-0 shadow-lg">
              <CardContent className="p-6">
                <h3 className="text-lg font-semibold text-slate-900 mb-4">✗ Restricted Uses</h3>
                <ul className="space-y-2 text-slate-600">
                  <li>• Redistribution without permission</li>
                  <li>• Commercial use outside partnership</li>
                  <li>• Modification of branded materials</li>
                  <li>• Use by competitors or unauthorized parties</li>
                </ul>
              </CardContent>
            </Card>
          </div>
          
          <div className="mt-8 p-6 bg-blue-50 rounded-lg">
            <p className="text-sm text-slate-600">
              <strong>Note:</strong> All materials are proprietary to Tech Japan by Talendy. 
              For questions about usage rights or to request permission for specific use cases, 
              please contact our legal team at legal@techjapan.talendy.world
            </p>
          </div>
        </div>
      </div>

      <Footer />
    </div>
  );
}