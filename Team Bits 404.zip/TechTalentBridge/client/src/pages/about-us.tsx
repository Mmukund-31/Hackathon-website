import Header from "@/components/header";
import Footer from "@/components/footer";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Building2, Users, Award, Target, Globe, TrendingUp } from "lucide-react";
import { useLanguage } from "@/lib/i18n";

export default function AboutUs() {
  const { t } = useLanguage();

  const achievements = [
    { icon: Users, number: "5,000+", label: "Engineers Deployed" },
    { icon: Building2, number: "200+", label: "Companies Served" },
    { icon: Globe, number: "15+", label: "Countries" },
    { icon: TrendingUp, number: "95%", label: "Client Satisfaction" }
  ];

  const managementTeam = [
    {
      name: "Hiroshi Tanaka",
      title: "CEO & Founder",
      experience: "15+ years in tech recruitment",
      background: "Former VP of Engineering at SoftBank",
      expertise: "Strategic partnerships, market expansion"
    },
    {
      name: "Priya Sharma",
      title: "Head of Engineering",
      experience: "12+ years in software development",
      background: "Ex-Google senior engineer",
      expertise: "Technical vetting, quality assurance"
    },
    {
      name: "Kenji Nakamura",
      title: "Head of Operations",
      experience: "10+ years in operations",
      background: "Former operations director at Rakuten",
      expertise: "Process optimization, client relations"
    }
  ];

  return (
    <div className="min-h-screen bg-background">
      <Header />
      
      {/* Hero Section */}
      <div className="bg-gradient-to-br from-primary to-blue-600 text-white py-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center">
            <h1 className="text-5xl font-bold mb-6">About Tech Japan by Talendy</h1>
            <p className="text-xl text-blue-100 max-w-3xl mx-auto leading-relaxed">
              Bridging the talent gap between Asia and India through innovative technology solutions 
              and exceptional engineering talent.
            </p>
          </div>
        </div>
      </div>

      {/* Company Vision & Mission */}
      <div className="py-16 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid lg:grid-cols-2 gap-12 items-center">
            <div>
              <div className="inline-flex items-center bg-primary/10 text-primary px-4 py-2 rounded-full text-sm font-medium mb-6">
                <Target className="w-4 h-4 mr-2" />
                Our Vision
              </div>
              <h2 className="text-4xl font-bold text-slate-900 mb-6">
                Transforming Global Tech Collaboration
              </h2>
              <p className="text-lg text-slate-600 mb-6 leading-relaxed">
                To become the leading platform connecting Asian companies with India's finest engineering talent, 
                creating sustainable partnerships that drive innovation and growth across borders.
              </p>
              <div className="space-y-4">
                <div className="flex items-start">
                  <div className="w-2 h-2 bg-primary rounded-full mt-3 mr-3"></div>
                  <p className="text-slate-600">Democratize access to world-class engineering talent</p>
                </div>
                <div className="flex items-start">
                  <div className="w-2 h-2 bg-primary rounded-full mt-3 mr-3"></div>
                  <p className="text-slate-600">Foster innovation through cultural and technical diversity</p>
                </div>
                <div className="flex items-start">
                  <div className="w-2 h-2 bg-primary rounded-full mt-3 mr-3"></div>
                  <p className="text-slate-600">Create lasting partnerships that benefit all stakeholders</p>
                </div>
              </div>
            </div>
            <div className="grid grid-cols-2 gap-4">
              {achievements.map((achievement, index) => (
                <Card key={index} className="text-center border-0 shadow-lg">
                  <CardContent className="p-6">
                    <achievement.icon className="w-8 h-8 text-primary mx-auto mb-3" />
                    <div className="text-3xl font-bold text-slate-900 mb-2">
                      {achievement.number}
                    </div>
                    <div className="text-sm text-slate-600">
                      {achievement.label}
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </div>
        </div>
      </div>

      {/* Company Story */}
      <div className="py-16 bg-slate-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="text-4xl font-bold text-slate-900 mb-4">Our Story</h2>
            <p className="text-xl text-slate-600 max-w-3xl mx-auto">
              Founded in 2018, Tech Japan emerged from a simple observation: 
              Asian companies needed better access to India's exceptional engineering talent.
            </p>
          </div>

          <div className="grid lg:grid-cols-3 gap-8">
            <Card className="border-0 shadow-lg">
              <CardContent className="p-8">
                <div className="w-12 h-12 bg-primary/10 rounded-lg flex items-center justify-center mb-6">
                  <span className="text-2xl font-bold text-primary">2018</span>
                </div>
                <h3 className="text-xl font-semibold text-slate-900 mb-4">The Beginning</h3>
                <p className="text-slate-600">
                  Started with a vision to connect Japanese startups with skilled Indian developers. 
                  Our first successful placement led to a 40% faster product launch.
                </p>
              </CardContent>
            </Card>

            <Card className="border-0 shadow-lg">
              <CardContent className="p-8">
                <div className="w-12 h-12 bg-primary/10 rounded-lg flex items-center justify-center mb-6">
                  <span className="text-2xl font-bold text-primary">2020</span>
                </div>
                <h3 className="text-xl font-semibold text-slate-900 mb-4">Expansion</h3>
                <p className="text-slate-600">
                  Expanded across Asia-Pacific, serving companies in South Korea, Singapore, and China. 
                  Achieved 500+ successful engineer placements.
                </p>
              </CardContent>
            </Card>

            <Card className="border-0 shadow-lg">
              <CardContent className="p-8">
                <div className="w-12 h-12 bg-primary/10 rounded-lg flex items-center justify-center mb-6">
                  <span className="text-2xl font-bold text-primary">2024</span>
                </div>
                <h3 className="text-xl font-semibold text-slate-900 mb-4">Innovation</h3>
                <p className="text-slate-600">
                  Launched AI-powered matching platform and comprehensive talent ecosystem. 
                  Now serving 200+ companies with 95% client satisfaction.
                </p>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>

      {/* Management Team */}
      <div className="py-16 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <div className="inline-flex items-center bg-primary/10 text-primary px-4 py-2 rounded-full text-sm font-medium mb-4">
              <Users className="w-4 h-4 mr-2" />
              Leadership Team
            </div>
            <h2 className="text-4xl font-bold text-slate-900 mb-4">Meet Our Management</h2>
            <p className="text-xl text-slate-600 max-w-3xl mx-auto">
              Experienced leaders combining deep technical expertise with strategic business acumen
            </p>
          </div>

          <div className="grid lg:grid-cols-3 gap-8">
            {managementTeam.map((member, index) => (
              <Card key={index} className="border-0 shadow-lg overflow-hidden">
                <div className="bg-gradient-to-r from-primary to-blue-600 p-6 text-white">
                  <div className="w-16 h-16 bg-white/20 rounded-full flex items-center justify-center mb-4 text-2xl font-bold">
                    {member.name.split(' ').map(n => n[0]).join('')}
                  </div>
                  <h3 className="text-xl font-semibold mb-2">{member.name}</h3>
                  <p className="text-blue-100">{member.title}</p>
                </div>
                <CardContent className="p-6">
                  <div className="space-y-4">
                    <div>
                      <h4 className="font-semibold text-slate-900 mb-1">Experience</h4>
                      <p className="text-sm text-slate-600">{member.experience}</p>
                    </div>
                    <div>
                      <h4 className="font-semibold text-slate-900 mb-1">Background</h4>
                      <p className="text-sm text-slate-600">{member.background}</p>
                    </div>
                    <div>
                      <h4 className="font-semibold text-slate-900 mb-1">Expertise</h4>
                      <p className="text-sm text-slate-600">{member.expertise}</p>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </div>

      {/* Corporate Information */}
      <div className="py-16 bg-slate-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid lg:grid-cols-2 gap-12">
            <div>
              <h2 className="text-3xl font-bold text-slate-900 mb-6">Corporate Information</h2>
              <div className="space-y-6">
                <div>
                  <h3 className="text-lg font-semibold text-slate-900 mb-2">Company Details</h3>
                  <div className="space-y-2 text-slate-600">
                    <p><strong>Legal Name:</strong> Tech Japan by Talendy K.K.</p>
                    <p><strong>Founded:</strong> 2018</p>
                    <p><strong>Headquarters:</strong> Tokyo, Japan</p>
                    <p><strong>Registration:</strong> Tokyo Metropolitan Government</p>
                  </div>
                </div>
                
                <div>
                  <h3 className="text-lg font-semibold text-slate-900 mb-2">Business Focus</h3>
                  <div className="space-y-1 text-slate-600">
                    <p>• Software Development Outsourcing</p>
                    <p>• Technical Talent Acquisition</p>
                    <p>• Cross-border Technology Consulting</p>
                    <p>• Engineering Team Augmentation</p>
                  </div>
                </div>
              </div>
            </div>

            <div>
              <h2 className="text-3xl font-bold text-slate-900 mb-6">Our Commitment</h2>
              <div className="space-y-4">
                <Card className="border-l-4 border-l-primary border-t-0 border-r-0 border-b-0 shadow-none bg-white">
                  <CardContent className="p-4">
                    <h3 className="font-semibold text-slate-900 mb-2">Quality Assurance</h3>
                    <p className="text-slate-600 text-sm">
                      Rigorous vetting process ensuring only top 5% of engineers join our network
                    </p>
                  </CardContent>
                </Card>
                
                <Card className="border-l-4 border-l-primary border-t-0 border-r-0 border-b-0 shadow-none bg-white">
                  <CardContent className="p-4">
                    <h3 className="font-semibold text-slate-900 mb-2">Cultural Bridge</h3>
                    <p className="text-slate-600 text-sm">
                      Deep understanding of Asian business culture and Indian technical expertise
                    </p>
                  </CardContent>
                </Card>
                
                <Card className="border-l-4 border-l-primary border-t-0 border-r-0 border-b-0 shadow-none bg-white">
                  <CardContent className="p-4">
                    <h3 className="font-semibold text-slate-900 mb-2">Continuous Support</h3>
                    <p className="text-slate-600 text-sm">
                      24/7 support ensuring seamless collaboration across time zones
                    </p>
                  </CardContent>
                </Card>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Call to Action */}
      <div className="py-16 bg-gradient-to-r from-primary to-blue-600 text-white">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h2 className="text-3xl font-bold mb-4">Ready to Transform Your Development?</h2>
          <p className="text-xl text-blue-100 mb-8">
            Join 200+ companies who have accelerated their growth with our engineering talent
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Button className="bg-white text-primary hover:bg-blue-50 px-8 py-3">
              Start Your Project
            </Button>
            <Button variant="outline" className="border-white text-white hover:bg-white hover:text-primary px-8 py-3">
              Contact Our Team
            </Button>
          </div>
        </div>
      </div>

      <Footer />
    </div>
  );
}