import Header from "@/components/header";
import Footer from "@/components/footer";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Checkbox } from "@/components/ui/checkbox";
import { User, Code, Award, Globe, CheckCircle, ArrowRight, Users } from "lucide-react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { useLanguage } from "@/lib/i18n";

const candidateFormSchema = z.object({
  firstName: z.string().min(2, "First name must be at least 2 characters"),
  lastName: z.string().min(2, "Last name must be at least 2 characters"),
  email: z.string().email("Please enter a valid email address"),
  phone: z.string().min(10, "Please enter a valid phone number"),
  experience: z.string().min(1, "Please select your experience level"),
  primarySkills: z.array(z.string()).min(1, "Please select at least one skill"),
  specialization: z.string().min(1, "Please select your specialization"),
  availability: z.string().min(1, "Please select your availability"),
  portfolio: z.string().url("Please enter a valid URL").optional().or(z.literal("")),
  github: z.string().url("Please enter a valid GitHub URL").optional().or(z.literal("")),
  linkedIn: z.string().url("Please enter a valid LinkedIn URL").optional().or(z.literal("")),
  education: z.string().min(2, "Please enter your education background"),
  certifications: z.string().optional(),
  coverLetter: z.string().min(50, "Please write at least 50 characters about yourself"),
  consent: z.boolean().refine(val => val, "Please accept the terms and conditions")
});

type CandidateFormData = z.infer<typeof candidateFormSchema>;

export default function ForCandidate() {
  const { t } = useLanguage();

  const form = useForm<CandidateFormData>({
    resolver: zodResolver(candidateFormSchema),
    defaultValues: {
      firstName: "",
      lastName: "",
      email: "",
      phone: "",
      experience: "",
      primarySkills: [],
      specialization: "",
      availability: "",
      portfolio: "",
      github: "",
      linkedIn: "",
      education: "",
      certifications: "",
      coverLetter: "",
      consent: false
    }
  });

  const onSubmit = (data: CandidateFormData) => {
    console.log("Engineer application submitted:", data);
    // In real implementation, this would submit to the API
  };

  const benefits = [
    {
      icon: Globe,
      title: "Work with Global Companies",
      description: "Collaborate with leading Asian companies on cutting-edge projects"
    },
    {
      icon: Award,
      title: "Competitive Compensation",
      description: "Earn competitive rates with transparent, timely payments"
    },
    {
      icon: Code,
      title: "Latest Technologies",
      description: "Work with modern tech stacks and emerging technologies"
    },
    {
      icon: Users,
      title: "Professional Growth",
      description: "Continuous learning opportunities and career advancement"
    }
  ];

  const requirements = [
    "3+ years of professional software development experience",
    "Strong proficiency in at least one major programming language",
    "Experience with modern frameworks and development tools",
    "Excellent English communication skills (written and verbal)",
    "Bachelor's degree in Computer Science or related field",
    "Proven track record of delivering quality software projects"
  ];

  const applicationProcess = [
    {
      step: 1,
      title: "Submit Application",
      description: "Complete the application form with your details and portfolio"
    },
    {
      step: 2,
      title: "Technical Assessment",
      description: "Complete coding challenges and technical interviews"
    },
    {
      step: 3,
      title: "Cultural Fit Interview",
      description: "Meet with our team to assess communication and collaboration skills"
    },
    {
      step: 4,
      title: "Welcome to Network",
      description: "Join our elite network and start working on exciting projects"
    }
  ];

  const skills = [
    "JavaScript", "TypeScript", "React", "Node.js", "Python", "Java", 
    "AWS", "Azure", "Docker", "Kubernetes", "MongoDB", "PostgreSQL",
    "GraphQL", "REST APIs", "Git", "CI/CD", "Machine Learning", "AI"
  ];

  const specializations = [
    { value: "frontend", label: "Frontend Development" },
    { value: "backend", label: "Backend Development" },
    { value: "fullstack", label: "Full-Stack Development" },
    { value: "mobile", label: "Mobile Development" },
    { value: "devops", label: "DevOps & Infrastructure" },
    { value: "ai-ml", label: "AI/Machine Learning" },
    { value: "blockchain", label: "Blockchain Development" },
    { value: "data", label: "Data Engineering" }
  ];

  return (
    <div className="min-h-screen bg-background">
      <Header />
      
      {/* Hero Section */}
      <div className="bg-gradient-to-br from-primary to-blue-600 text-white py-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center">
            <User className="w-16 h-16 mx-auto mb-6 opacity-80" />
            <h1 className="text-5xl font-bold mb-6">Join Our Elite Engineering Network</h1>
            <p className="text-xl text-blue-100 max-w-3xl mx-auto">
              Connect with leading Asian companies and work on innovative projects that shape the future of technology
            </p>
          </div>
        </div>
      </div>

      {/* Why Join Us */}
      <div className="py-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="text-4xl font-bold text-slate-900 mb-4">Why Choose Tech Japan?</h2>
            <p className="text-xl text-slate-600 max-w-3xl mx-auto">
              Join a curated network of top engineers working with innovative companies across Asia
            </p>
          </div>

          <div className="grid lg:grid-cols-4 gap-8">
            {benefits.map((benefit, index) => (
              <Card key={index} className="border-0 shadow-lg text-center">
                <CardContent className="p-8">
                  <benefit.icon className="w-12 h-12 text-primary mx-auto mb-4" />
                  <h3 className="text-xl font-semibold text-slate-900 mb-3">{benefit.title}</h3>
                  <p className="text-slate-600">{benefit.description}</p>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </div>

      {/* Application Process */}
      <div className="py-16 bg-slate-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="text-4xl font-bold text-slate-900 mb-4">Application Process</h2>
            <p className="text-xl text-slate-600">Simple, transparent process to join our network</p>
          </div>

          <div className="grid lg:grid-cols-4 gap-8">
            {applicationProcess.map((process, index) => (
              <div key={index} className="relative">
                <Card className="border-0 shadow-lg">
                  <CardContent className="p-6 text-center">
                    <div className="w-12 h-12 bg-primary rounded-full flex items-center justify-center text-white font-bold text-xl mx-auto mb-4">
                      {process.step}
                    </div>
                    <h3 className="text-lg font-semibold text-slate-900 mb-3">{process.title}</h3>
                    <p className="text-slate-600">{process.description}</p>
                  </CardContent>
                </Card>
                {index < applicationProcess.length - 1 && (
                  <ArrowRight className="hidden lg:block absolute top-1/2 -right-4 transform -translate-y-1/2 text-primary w-8 h-8" />
                )}
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Requirements */}
      <div className="py-16">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="text-4xl font-bold text-slate-900 mb-4">Minimum Requirements</h2>
            <p className="text-xl text-slate-600">
              We maintain high standards to ensure quality for our clients
            </p>
          </div>

          <Card className="border-0 shadow-lg">
            <CardContent className="p-8">
              <div className="grid md:grid-cols-2 gap-6">
                {requirements.map((requirement, index) => (
                  <div key={index} className="flex items-start">
                    <CheckCircle className="w-5 h-5 text-green-500 mr-3 mt-0.5 flex-shrink-0" />
                    <span className="text-slate-700">{requirement}</span>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </div>
      </div>

      {/* Application Form */}
      <div className="py-16 bg-slate-50">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="text-4xl font-bold text-slate-900 mb-4">Apply Now</h2>
            <p className="text-xl text-slate-600">
              Take the first step towards joining our elite engineering network
            </p>
          </div>

          <Card className="border-0 shadow-xl">
            <CardContent className="p-8">
              <Form {...form}>
                <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
                  {/* Personal Information */}
                  <div>
                    <h3 className="text-lg font-semibold text-slate-900 mb-4">Personal Information</h3>
                    <div className="grid md:grid-cols-2 gap-4">
                      <FormField
                        control={form.control}
                        name="firstName"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>First Name</FormLabel>
                            <FormControl>
                              <Input {...field} />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                      <FormField
                        control={form.control}
                        name="lastName"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Last Name</FormLabel>
                            <FormControl>
                              <Input {...field} />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                    </div>
                    
                    <div className="grid md:grid-cols-2 gap-4 mt-4">
                      <FormField
                        control={form.control}
                        name="email"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Email Address</FormLabel>
                            <FormControl>
                              <Input type="email" {...field} />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                      <FormField
                        control={form.control}
                        name="phone"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Phone Number</FormLabel>
                            <FormControl>
                              <Input {...field} />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                    </div>
                  </div>

                  {/* Professional Information */}
                  <div>
                    <h3 className="text-lg font-semibold text-slate-900 mb-4">Professional Information</h3>
                    <div className="grid md:grid-cols-2 gap-4">
                      <FormField
                        control={form.control}
                        name="experience"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Experience Level</FormLabel>
                            <Select onValueChange={field.onChange} defaultValue={field.value}>
                              <FormControl>
                                <SelectTrigger>
                                  <SelectValue placeholder="Select experience level" />
                                </SelectTrigger>
                              </FormControl>
                              <SelectContent>
                                <SelectItem value="junior">Junior (1-3 years)</SelectItem>
                                <SelectItem value="mid">Mid-level (3-6 years)</SelectItem>
                                <SelectItem value="senior">Senior (6+ years)</SelectItem>
                                <SelectItem value="lead">Tech Lead/Architect (8+ years)</SelectItem>
                              </SelectContent>
                            </Select>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                      <FormField
                        control={form.control}
                        name="specialization"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Primary Specialization</FormLabel>
                            <Select onValueChange={field.onChange} defaultValue={field.value}>
                              <FormControl>
                                <SelectTrigger>
                                  <SelectValue placeholder="Select specialization" />
                                </SelectTrigger>
                              </FormControl>
                              <SelectContent>
                                {specializations.map((spec) => (
                                  <SelectItem key={spec.value} value={spec.value}>
                                    {spec.label}
                                  </SelectItem>
                                ))}
                              </SelectContent>
                            </Select>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                    </div>

                    <FormField
                      control={form.control}
                      name="education"
                      render={({ field }) => (
                        <FormItem className="mt-4">
                          <FormLabel>Education Background</FormLabel>
                          <FormControl>
                            <Input placeholder="e.g., B.Tech Computer Science, IIT Delhi" {...field} />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />

                    <FormField
                      control={form.control}
                      name="certifications"
                      render={({ field }) => (
                        <FormItem className="mt-4">
                          <FormLabel>Certifications (Optional)</FormLabel>
                          <FormControl>
                            <Input placeholder="e.g., AWS Certified, Google Cloud Professional" {...field} />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                  </div>

                  {/* Portfolio Links */}
                  <div>
                    <h3 className="text-lg font-semibold text-slate-900 mb-4">Portfolio & Links</h3>
                    <div className="grid md:grid-cols-3 gap-4">
                      <FormField
                        control={form.control}
                        name="portfolio"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Portfolio URL</FormLabel>
                            <FormControl>
                              <Input placeholder="https://yourportfolio.com" {...field} />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                      <FormField
                        control={form.control}
                        name="github"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>GitHub Profile</FormLabel>
                            <FormControl>
                              <Input placeholder="https://github.com/username" {...field} />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                      <FormField
                        control={form.control}
                        name="linkedIn"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>LinkedIn Profile</FormLabel>
                            <FormControl>
                              <Input placeholder="https://linkedin.com/in/username" {...field} />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                    </div>
                  </div>

                  {/* Availability */}
                  <FormField
                    control={form.control}
                    name="availability"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Availability</FormLabel>
                        <Select onValueChange={field.onChange} defaultValue={field.value}>
                          <FormControl>
                            <SelectTrigger>
                              <SelectValue placeholder="Select your availability" />
                            </SelectTrigger>
                          </FormControl>
                          <SelectContent>
                            <SelectItem value="immediate">Available Immediately</SelectItem>
                            <SelectItem value="1-week">Available in 1 week</SelectItem>
                            <SelectItem value="2-weeks">Available in 2 weeks</SelectItem>
                            <SelectItem value="1-month">Available in 1 month</SelectItem>
                          </SelectContent>
                        </Select>
                        <FormMessage />
                      </FormItem>
                    )}
                  />

                  {/* Cover Letter */}
                  <FormField
                    control={form.control}
                    name="coverLetter"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Tell Us About Yourself</FormLabel>
                        <FormControl>
                          <Textarea 
                            className="min-h-[120px]"
                            placeholder="Share your experience, notable projects, and why you'd like to join our network..."
                            {...field} 
                          />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />

                  {/* Terms and Conditions */}
                  <FormField
                    control={form.control}
                    name="consent"
                    render={({ field }) => (
                      <FormItem className="flex flex-row items-start space-x-3 space-y-0">
                        <FormControl>
                          <Checkbox
                            checked={field.value}
                            onCheckedChange={field.onChange}
                          />
                        </FormControl>
                        <div className="space-y-1 leading-none">
                          <FormLabel>
                            I agree to the terms and conditions and privacy policy
                          </FormLabel>
                          <FormMessage />
                        </div>
                      </FormItem>
                    )}
                  />

                  <Button type="submit" className="w-full bg-primary hover:bg-blue-700 py-3">
                    Submit Application
                  </Button>
                </form>
              </Form>
            </CardContent>
          </Card>
        </div>
      </div>

      <Footer />
    </div>
  );
}