import Header from "@/components/header";
import Hero from "@/components/hero";
import ProblemSolution from "@/components/problem-solution";
import Services from "@/components/services";
import TalentPool from "@/components/talent-pool";
import EngineerShowcase from "@/components/engineer-showcase";
import PricingCalculator from "@/components/pricing-calculator";
import CaseStudies from "@/components/case-studies";
import SuccessStories from "@/components/success-stories";
import TestimonialVideo from "@/components/testimonial-video";
import LocalizedContent from "@/components/localized-content";
import EnhancedCTA from "@/components/enhanced-cta";
import Contact from "@/components/contact";
import Footer from "@/components/footer";
import ChatWidget from "@/components/chat-widget";
import SEOHead from "@/components/seo-head";

export default function Home() {
  // Structured data for SEO
  const structuredData = {
    "@context": "https://schema.org",
    "@type": "Organization",
    "name": "Tech Japan by Talendy",
    "url": "https://www.talendy.world",
    "logo": "https://www.talendy.world/logo.png",
    "description": "Elite Indian engineers for Asian tech companies with 60% cost reduction and 48-hour deployment.",
    "serviceType": ["Software Development", "Engineering Outsourcing", "Technical Consulting"],
    "areaServed": ["Japan", "South Korea", "China", "Singapore", "Asia"],
    "aggregateRating": {
      "@type": "AggregateRating",
      "ratingValue": "4.8",
      "reviewCount": "200"
    },
    "offers": {
      "@type": "Offer",
      "description": "60% cost reduction with 48-hour engineer deployment",
      "price": "Varies",
      "priceCurrency": "USD"
    }
  };

  return (
    <div className="min-h-screen bg-background">
      <SEOHead 
        structuredData={structuredData}
        canonical="https://www.talendy.world"
      />
      <Header />
      <Hero />
      <ProblemSolution />
      <Services />
      <EngineerShowcase />
      <PricingCalculator />
      <CaseStudies />
      <LocalizedContent />
      <EnhancedCTA variant="primary" showBenefits={true} />
      <TalentPool />
      <TestimonialVideo />
      <EnhancedCTA 
        variant="consultation" 
        title="Get Your Free Strategy Session"
        subtitle="Discover how to reduce development costs by 60% while accelerating delivery"
        showBenefits={false}
      />
      <SuccessStories />
      <Contact />
      <Footer />
      <ChatWidget />
    </div>
  );
}
