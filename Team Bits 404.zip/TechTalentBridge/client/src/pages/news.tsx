import Header from "@/components/header";
import Footer from "@/components/footer";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Calendar, Clock, User, Search, Filter, Newspaper, TrendingUp } from "lucide-react";
import { useState } from "react";
import { useLanguage } from "@/lib/i18n";

interface NewsArticle {
  id: number;
  title: string;
  excerpt: string;
  content: string;
  category: string;
  author: string;
  publishDate: string;
  readTime: number;
  tags: string[];
  featured: boolean;
}

export default function News() {
  const [searchQuery, setSearchQuery] = useState("");
  const [selectedCategory, setSelectedCategory] = useState("all");
  const { t } = useLanguage();

  const categories = [
    { value: "all", label: "All News" },
    { value: "company", label: "Company Updates" },
    { value: "industry", label: "Industry Trends" },
    { value: "success", label: "Success Stories" },
    { value: "technology", label: "Technology" },
    { value: "partnerships", label: "Partnerships" }
  ];

  const newsArticles: NewsArticle[] = [
    {
      id: 1,
      title: "Tech Japan Expands Operations to Southeast Asia",
      excerpt: "We're excited to announce our expansion into Singapore and Thailand, bringing our proven engineering talent solutions to more companies across the region.",
      content: "Full article content would be loaded here...",
      category: "company",
      author: "Hiroshi Tanaka",
      publishDate: "2024-12-15",
      readTime: 5,
      tags: ["expansion", "southeast-asia", "growth"],
      featured: true
    },
    {
      id: 2,
      title: "The Rise of AI Development in Asian Markets",
      excerpt: "Exploring how Asian companies are leveraging artificial intelligence and machine learning to drive innovation and competitive advantage.",
      content: "Full article content would be loaded here...",
      category: "industry",
      author: "Priya Sharma",
      publishDate: "2024-12-10",
      readTime: 8,
      tags: ["ai", "machine-learning", "innovation"],
      featured: true
    },
    {
      id: 3,
      title: "Client Success: 300% Faster Development with Our Engineering Team",
      excerpt: "How a Japanese fintech startup reduced their development timeline from 18 months to 6 months using our skilled engineering talent.",
      content: "Full article content would be loaded here...",
      category: "success",
      author: "Kenji Nakamura",
      publishDate: "2024-12-05",
      readTime: 6,
      tags: ["success-story", "fintech", "development"],
      featured: false
    },
    {
      id: 4,
      title: "Partnership with Leading Asian Universities",
      excerpt: "Tech Japan announces strategic partnerships with top engineering universities to create a direct pipeline of fresh talent.",
      content: "Full article content would be loaded here...",
      category: "partnerships",
      author: "Tech Japan Team",
      publishDate: "2024-11-28",
      readTime: 4,
      tags: ["partnership", "education", "talent"],
      featured: false
    },
    {
      id: 5,
      title: "Blockchain Development Trends in 2025",
      excerpt: "An in-depth analysis of blockchain technology adoption across Asian markets and emerging opportunities.",
      content: "Full article content would be loaded here...",
      category: "technology",
      author: "Priya Sharma",
      publishDate: "2024-11-20",
      readTime: 10,
      tags: ["blockchain", "trends", "2025"],
      featured: false
    },
    {
      id: 6,
      title: "Reaching 5,000 Engineer Milestone",
      excerpt: "Celebrating a major milestone as we welcome our 5,000th engineer to the Tech Japan network.",
      content: "Full article content would be loaded here...",
      category: "company",
      author: "Hiroshi Tanaka",
      publishDate: "2024-11-15",
      readTime: 3,
      tags: ["milestone", "growth", "engineers"],
      featured: false
    }
  ];

  const filteredArticles = newsArticles.filter(article => {
    const matchesSearch = searchQuery === "" || 
      article.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
      article.excerpt.toLowerCase().includes(searchQuery.toLowerCase()) ||
      article.tags.some(tag => tag.toLowerCase().includes(searchQuery.toLowerCase()));
    
    const matchesCategory = selectedCategory === "all" || article.category === selectedCategory;
    
    return matchesSearch && matchesCategory;
  });

  const featuredArticles = filteredArticles.filter(article => article.featured);
  const regularArticles = filteredArticles.filter(article => !article.featured);

  const formatDate = (dateString: string) => {
    const date = new Date(dateString);
    return date.toLocaleDateString('en-US', { 
      year: 'numeric', 
      month: 'long', 
      day: 'numeric' 
    });
  };

  const getCategoryColor = (category: string) => {
    const colors = {
      company: "bg-blue-100 text-blue-800",
      industry: "bg-green-100 text-green-800",
      success: "bg-purple-100 text-purple-800",
      technology: "bg-orange-100 text-orange-800",
      partnerships: "bg-pink-100 text-pink-800"
    };
    return colors[category as keyof typeof colors] || "bg-gray-100 text-gray-800";
  };

  return (
    <div className="min-h-screen bg-background">
      <Header />
      
      {/* Hero Section */}
      <div className="bg-gradient-to-br from-primary to-blue-600 text-white py-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center">
            <Newspaper className="w-16 h-16 mx-auto mb-6 opacity-80" />
            <h1 className="text-5xl font-bold mb-6">Tech Japan News</h1>
            <p className="text-xl text-blue-100 max-w-3xl mx-auto">
              Stay updated with the latest developments, industry insights, and success stories from Tech Japan
            </p>
          </div>
        </div>
      </div>

      {/* Search and Filter */}
      <div className="py-8 bg-slate-50 border-b">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex flex-col md:flex-row gap-4">
            <div className="flex-1 relative">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-slate-400 w-5 h-5" />
              <Input
                type="text"
                placeholder="Search news articles..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="pl-10"
              />
            </div>
            <div className="flex items-center gap-4">
              <Filter className="w-5 h-5 text-slate-600" />
              <Select value={selectedCategory} onValueChange={setSelectedCategory}>
                <SelectTrigger className="w-48">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  {categories.map((category) => (
                    <SelectItem key={category.value} value={category.value}>
                      {category.label}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          </div>
        </div>
      </div>

      {/* Featured Articles */}
      {featuredArticles.length > 0 && (
        <div className="py-16">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="flex items-center mb-8">
              <TrendingUp className="w-6 h-6 text-primary mr-3" />
              <h2 className="text-3xl font-bold text-slate-900">Featured Stories</h2>
            </div>
            
            <div className="grid lg:grid-cols-2 gap-8">
              {featuredArticles.map((article) => (
                <Card key={article.id} className="border-0 shadow-xl overflow-hidden">
                  <div className="bg-gradient-to-r from-primary to-blue-600 p-6 text-white">
                    <Badge className="bg-white/20 text-white mb-4">Featured</Badge>
                    <h3 className="text-2xl font-bold mb-3">{article.title}</h3>
                    <p className="text-blue-100 leading-relaxed">{article.excerpt}</p>
                  </div>
                  <CardContent className="p-6">
                    <div className="flex items-center justify-between mb-4">
                      <Badge className={getCategoryColor(article.category)}>
                        {categories.find(c => c.value === article.category)?.label}
                      </Badge>
                      <div className="flex items-center text-sm text-slate-500">
                        <Clock className="w-4 h-4 mr-1" />
                        {article.readTime} min read
                      </div>
                    </div>
                    
                    <div className="flex items-center justify-between">
                      <div className="flex items-center text-sm text-slate-600">
                        <User className="w-4 h-4 mr-1" />
                        {article.author}
                        <Calendar className="w-4 h-4 ml-4 mr-1" />
                        {formatDate(article.publishDate)}
                      </div>
                      <Button>Read More</Button>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* Regular Articles */}
      <div className="py-16 bg-slate-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          {regularArticles.length > 0 ? (
            <>
              <h2 className="text-3xl font-bold text-slate-900 mb-8">Latest News</h2>
              <div className="grid lg:grid-cols-3 gap-8">
                {regularArticles.map((article) => (
                  <Card key={article.id} className="border-0 shadow-lg">
                    <CardHeader className="pb-4">
                      <div className="flex items-center justify-between mb-3">
                        <Badge className={getCategoryColor(article.category)}>
                          {categories.find(c => c.value === article.category)?.label}
                        </Badge>
                        <div className="flex items-center text-sm text-slate-500">
                          <Clock className="w-4 h-4 mr-1" />
                          {article.readTime} min
                        </div>
                      </div>
                      <CardTitle className="text-xl leading-tight">{article.title}</CardTitle>
                    </CardHeader>
                    <CardContent>
                      <p className="text-slate-600 mb-4 leading-relaxed">{article.excerpt}</p>
                      
                      <div className="flex flex-wrap gap-2 mb-4">
                        {article.tags.map((tag, index) => (
                          <Badge key={index} variant="outline" className="text-xs">
                            #{tag}
                          </Badge>
                        ))}
                      </div>
                      
                      <div className="flex items-center justify-between">
                        <div className="text-sm text-slate-600">
                          <div className="flex items-center mb-1">
                            <User className="w-4 h-4 mr-1" />
                            {article.author}
                          </div>
                          <div className="flex items-center">
                            <Calendar className="w-4 h-4 mr-1" />
                            {formatDate(article.publishDate)}
                          </div>
                        </div>
                        <Button variant="outline" size="sm">
                          Read More
                        </Button>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            </>
          ) : (
            <Card className="border-0 shadow-lg text-center py-12">
              <CardContent>
                <Search className="w-12 h-12 text-slate-400 mx-auto mb-4" />
                <h3 className="text-xl font-semibold text-slate-900 mb-2">No articles found</h3>
                <p className="text-slate-600 mb-4">
                  No articles match your current search and filter criteria.
                </p>
                <Button 
                  onClick={() => {
                    setSearchQuery("");
                    setSelectedCategory("all");
                  }} 
                  variant="outline"
                >
                  Clear Filters
                </Button>
              </CardContent>
            </Card>
          )}
        </div>
      </div>

      {/* Newsletter Signup */}
      <div className="py-16 bg-gradient-to-r from-primary to-blue-600 text-white">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h2 className="text-3xl font-bold mb-4">Stay Updated</h2>
          <p className="text-xl text-blue-100 mb-8">
            Subscribe to our newsletter for the latest news and insights
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center max-w-md mx-auto">
            <Input 
              type="email" 
              placeholder="Enter your email"
              className="bg-white text-slate-900 border-0"
            />
            <Button className="bg-white text-primary hover:bg-blue-50">
              Subscribe
            </Button>
          </div>
        </div>
      </div>

      <Footer />
    </div>
  );
}