import Header from "@/components/header";
import Footer from "@/components/footer";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from "@/components/ui/accordion";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { HelpCircle, Search, MessageCircle, Clock, Users, Shield } from "lucide-react";
import { useState } from "react";
import { useLanguage } from "@/lib/i18n";

export default function FAQ() {
  const [searchQuery, setSearchQuery] = useState("");
  const { t } = useLanguage();

  const faqCategories = [
    {
      id: "getting-started",
      title: "Getting Started",
      icon: Users,
      questions: [
        {
          question: "How do I start hiring engineers through Tech Japan?",
          answer: "Simply fill out our contact form with your project requirements. Our team will review your needs and match you with suitable engineers within 48 hours. We'll schedule a consultation to understand your specific requirements and present pre-vetted candidates."
        },
        {
          question: "What is the minimum project duration?",
          answer: "We accommodate projects of all sizes, from short-term engagements of 1 month to long-term partnerships spanning multiple years. However, we recommend a minimum 3-month engagement to ensure optimal project outcomes and team integration."
        },
        {
          question: "How quickly can engineers start working?",
          answer: "Our engineers can typically start within 48 hours of project confirmation. For specialized roles or specific technical stacks, it may take up to 1 week to ensure the perfect match."
        }
      ]
    },
    {
      id: "engineers",
      title: "Engineer Quality & Vetting",
      icon: Shield,
      questions: [
        {
          question: "How do you vet your engineers?",
          answer: "Our rigorous 5-stage vetting process includes: technical assessments, coding challenges, system design interviews, English proficiency tests, and cultural fit evaluations. Only the top 5% of applicants join our network."
        },
        {
          question: "What experience levels are available?",
          answer: "We offer engineers across all experience levels: Junior (1-3 years), Mid-level (3-6 years), Senior (6+ years), and Tech Leads/Architects (8+ years). Each engineer is matched based on your project complexity and requirements."
        },
        {
          question: "Do engineers speak English fluently?",
          answer: "Yes, all our engineers are required to demonstrate business-level English proficiency. Many also speak additional Asian languages including Japanese, Korean, and Mandarin."
        }
      ]
    },
    {
      id: "pricing",
      title: "Pricing & Payments",
      icon: Clock,
      questions: [
        {
          question: "How much can I save compared to local hiring?",
          answer: "Our clients typically save 50-70% compared to local hiring costs while maintaining the same quality standards. Use our pricing calculator on the homepage for specific estimates based on your requirements."
        },
        {
          question: "What are the payment terms?",
          answer: "We offer flexible payment terms including monthly billing, milestone-based payments, or custom arrangements. All payments are processed securely through our platform with full transparency."
        },
        {
          question: "Are there any hidden fees?",
          answer: "No hidden fees. Our pricing includes engineer salaries, platform fees, and support services. The only additional costs might be specific tools or software licenses your project requires."
        }
      ]
    },
    {
      id: "technical",
      title: "Technical & Project Management",
      icon: MessageCircle,
      questions: [
        {
          question: "What technologies and frameworks do your engineers work with?",
          answer: "Our engineers are proficient in a wide range of technologies including React, Node.js, Python, Java, AWS, Azure, mobile development (iOS/Android), AI/ML, blockchain, and more. We match engineers based on your specific tech stack."
        },
        {
          question: "How do you handle time zone differences?",
          answer: "Our engineers are flexible with working hours and can overlap with Asian business hours. We also provide project management tools and regular updates to ensure smooth communication across time zones."
        },
        {
          question: "What project management methodologies do you support?",
          answer: "We support various methodologies including Agile, Scrum, Kanban, and Waterfall. Our engineers are experienced in tools like Jira, Trello, Asana, and can adapt to your existing workflows."
        }
      ]
    }
  ];

  const filteredCategories = faqCategories.map(category => ({
    ...category,
    questions: category.questions.filter(q => 
      searchQuery === "" || 
      q.question.toLowerCase().includes(searchQuery.toLowerCase()) ||
      q.answer.toLowerCase().includes(searchQuery.toLowerCase())
    )
  })).filter(category => category.questions.length > 0);

  return (
    <div className="min-h-screen bg-background">
      <Header />
      
      {/* Hero Section */}
      <div className="bg-gradient-to-br from-primary to-blue-600 text-white py-16">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <HelpCircle className="w-16 h-16 mx-auto mb-6 opacity-80" />
          <h1 className="text-5xl font-bold mb-6">Frequently Asked Questions</h1>
          <p className="text-xl text-blue-100 mb-8">
            Find answers to common questions about hiring Indian engineers through Tech Japan
          </p>
          
          {/* Search Bar */}
          <div className="relative max-w-md mx-auto">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-slate-400 w-5 h-5" />
            <Input
              type="text"
              placeholder="Search FAQs..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="pl-10 py-3 bg-white text-slate-900 border-0 rounded-lg shadow-lg"
            />
          </div>
        </div>
      </div>

      {/* FAQ Content */}
      <div className="py-16">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
          {filteredCategories.length > 0 ? (
            <div className="space-y-8">
              {filteredCategories.map((category) => (
                <Card key={category.id} className="border-0 shadow-lg">
                  <CardHeader className="bg-slate-50">
                    <CardTitle className="flex items-center text-xl text-slate-900">
                      <category.icon className="w-6 h-6 mr-3 text-primary" />
                      {category.title}
                      <Badge variant="secondary" className="ml-auto">
                        {category.questions.length} questions
                      </Badge>
                    </CardTitle>
                  </CardHeader>
                  <CardContent className="p-0">
                    <Accordion type="single" collapsible className="w-full">
                      {category.questions.map((faq, index) => (
                        <AccordionItem key={index} value={`${category.id}-${index}`} className="border-b last:border-b-0">
                          <AccordionTrigger className="px-6 py-4 text-left hover:no-underline hover:bg-slate-50">
                            <span className="font-medium text-slate-900">{faq.question}</span>
                          </AccordionTrigger>
                          <AccordionContent className="px-6 pb-4">
                            <p className="text-slate-600 leading-relaxed">{faq.answer}</p>
                          </AccordionContent>
                        </AccordionItem>
                      ))}
                    </Accordion>
                  </CardContent>
                </Card>
              ))}
            </div>
          ) : (
            <Card className="border-0 shadow-lg text-center py-12">
              <CardContent>
                <Search className="w-12 h-12 text-slate-400 mx-auto mb-4" />
                <h3 className="text-xl font-semibold text-slate-900 mb-2">No results found</h3>
                <p className="text-slate-600 mb-4">
                  We couldn't find any FAQs matching "{searchQuery}". Try adjusting your search terms.
                </p>
                <Button onClick={() => setSearchQuery("")} variant="outline">
                  Clear Search
                </Button>
              </CardContent>
            </Card>
          )}
        </div>
      </div>

      {/* Contact Support */}
      <div className="py-16 bg-slate-50">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h2 className="text-3xl font-bold text-slate-900 mb-4">Still Have Questions?</h2>
          <p className="text-xl text-slate-600 mb-8">
            Our team is here to help you find the perfect engineering solution
          </p>
          
          <div className="grid md:grid-cols-3 gap-6 mb-8">
            <Card className="border-0 shadow-lg">
              <CardContent className="p-6 text-center">
                <MessageCircle className="w-8 h-8 text-primary mx-auto mb-3" />
                <h3 className="font-semibold text-slate-900 mb-2">Live Chat</h3>
                <p className="text-slate-600 text-sm mb-4">
                  Chat with our support team in real-time
                </p>
                <Button className="w-full">Start Chat</Button>
              </CardContent>
            </Card>
            
            <Card className="border-0 shadow-lg">
              <CardContent className="p-6 text-center">
                <HelpCircle className="w-8 h-8 text-primary mx-auto mb-3" />
                <h3 className="font-semibold text-slate-900 mb-2">Email Support</h3>
                <p className="text-slate-600 text-sm mb-4">
                  Get detailed answers via email
                </p>
                <Button variant="outline" className="w-full">
                  Send Email
                </Button>
              </CardContent>
            </Card>
            
            <Card className="border-0 shadow-lg">
              <CardContent className="p-6 text-center">
                <Clock className="w-8 h-8 text-primary mx-auto mb-3" />
                <h3 className="font-semibold text-slate-900 mb-2">Schedule Call</h3>
                <p className="text-slate-600 text-sm mb-4">
                  Book a consultation with our experts
                </p>
                <Button variant="outline" className="w-full">
                  Book Call
                </Button>
              </CardContent>
            </Card>
          </div>
          
          <div className="bg-white rounded-lg p-6 border border-slate-200">
            <h3 className="text-lg font-semibold text-slate-900 mb-2">Business Hours</h3>
            <div className="grid md:grid-cols-3 gap-4 text-sm text-slate-600">
              <div>
                <strong>Japan:</strong> Mon-Fri 9:00-18:00 JST
              </div>
              <div>
                <strong>Korea:</strong> Mon-Fri 9:00-18:00 KST
              </div>
              <div>
                <strong>Singapore:</strong> Mon-Fri 9:00-18:00 SGT
              </div>
            </div>
          </div>
        </div>
      </div>

      <Footer />
    </div>
  );
}