import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Progress } from "@/components/ui/progress";
import { 
  Users, 
  TrendingUp, 
  Eye, 
  MousePointer, 
  Mail, 
  Phone,
  Calendar,
  DollarSign,
  BarChart3,
  Activity
} from "lucide-react";
import { useLanguage } from "@/lib/i18n";

interface AnalyticsData {
  totalVisitors: number;
  pageViews: number;
  contactForms: number;
  conversionRate: number;
  topPages: Array<{ path: string; views: number }>;
  recentSubmissions: Array<{
    id: number;
    companyName: string;
    email: string;
    status: string;
    createdAt: string;
  }>;
  monthlyStats: Array<{
    month: string;
    visitors: number;
    conversions: number;
  }>;
}

export default function Dashboard() {
  const { t } = useLanguage();

  const { data: analytics, isLoading } = useQuery<AnalyticsData>({
    queryKey: ['/api/analytics/dashboard'],
    refetchInterval: 30000, // Refresh every 30 seconds
  });

  if (isLoading) {
    return (
      <div className="min-h-screen bg-slate-50 p-6">
        <div className="max-w-7xl mx-auto">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8">
            {[...Array(4)].map((_, i) => (
              <Card key={i} className="animate-pulse">
                <CardHeader className="space-y-2">
                  <div className="h-4 bg-slate-200 rounded w-1/2"></div>
                  <div className="h-8 bg-slate-200 rounded w-3/4"></div>
                </CardHeader>
              </Card>
            ))}
          </div>
        </div>
      </div>
    );
  }

  const stats = [
    {
      title: "Total Visitors",
      value: analytics?.totalVisitors || 0,
      change: "+12.5%",
      icon: Users,
      color: "text-blue-600"
    },
    {
      title: "Page Views",
      value: analytics?.pageViews || 0,
      change: "+8.2%",
      icon: Eye,
      color: "text-green-600"
    },
    {
      title: "Contact Forms",
      value: analytics?.contactForms || 0,
      change: "+23.1%",
      icon: Mail,
      color: "text-purple-600"
    },
    {
      title: "Conversion Rate",
      value: `${analytics?.conversionRate || 0}%`,
      change: "+5.4%",
      icon: TrendingUp,
      color: "text-orange-600"
    }
  ];

  return (
    <div className="min-h-screen bg-slate-50">
      <div className="bg-white border-b border-slate-200 px-6 py-4">
        <div className="max-w-7xl mx-auto">
          <h1 className="text-3xl font-bold text-slate-900">Analytics Dashboard</h1>
          <p className="text-slate-600 mt-2">Track user engagement and conversion metrics</p>
        </div>
      </div>

      <div className="max-w-7xl mx-auto p-6">
        {/* Key Metrics */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8">
          {stats.map((stat, index) => (
            <Card key={index}>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium text-slate-600">
                  {stat.title}
                </CardTitle>
                <stat.icon className={`h-4 w-4 ${stat.color}`} />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold text-slate-900">{stat.value}</div>
                <p className="text-xs text-green-600 flex items-center mt-1">
                  <TrendingUp className="h-3 w-3 mr-1" />
                  {stat.change} from last month
                </p>
              </CardContent>
            </Card>
          ))}
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-8">
          {/* Top Pages */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center">
                <BarChart3 className="h-5 w-5 mr-2 text-blue-600" />
                Top Pages
              </CardTitle>
              <CardDescription>Most visited pages this month</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {analytics?.topPages?.map((page, index) => (
                  <div key={index} className="flex items-center justify-between">
                    <div className="flex items-center space-x-3">
                      <div className="w-8 h-8 bg-blue-100 rounded-lg flex items-center justify-center">
                        <span className="text-blue-600 font-semibold text-sm">
                          {index + 1}
                        </span>
                      </div>
                      <span className="font-medium text-slate-900">
                        {page.path === '/' ? 'Home' : page.path}
                      </span>
                    </div>
                    <Badge variant="secondary">{page.views} views</Badge>
                  </div>
                )) || (
                  <div className="text-center py-8">
                    <Activity className="h-12 w-12 text-slate-300 mx-auto mb-4" />
                    <p className="text-slate-500">No page view data available</p>
                  </div>
                )}
              </div>
            </CardContent>
          </Card>

          {/* Recent Contact Submissions */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center">
                <Mail className="h-5 w-5 mr-2 text-green-600" />
                Recent Submissions
              </CardTitle>
              <CardDescription>Latest contact form submissions</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {analytics?.recentSubmissions?.map((submission) => (
                  <div key={submission.id} className="flex items-center justify-between p-3 bg-slate-50 rounded-lg">
                    <div>
                      <p className="font-medium text-slate-900">{submission.companyName}</p>
                      <p className="text-sm text-slate-500">{submission.email}</p>
                    </div>
                    <div className="text-right">
                      <Badge 
                        variant={submission.status === 'new' ? 'default' : 'secondary'}
                        className="mb-1"
                      >
                        {submission.status}
                      </Badge>
                      <p className="text-xs text-slate-500">
                        {new Date(submission.createdAt).toLocaleDateString()}
                      </p>
                    </div>
                  </div>
                )) || (
                  <div className="text-center py-8">
                    <Mail className="h-12 w-12 text-slate-300 mx-auto mb-4" />
                    <p className="text-slate-500">No submissions yet</p>
                  </div>
                )}
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Monthly Performance */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center">
              <Calendar className="h-5 w-5 mr-2 text-purple-600" />
              Monthly Performance
            </CardTitle>
            <CardDescription>Visitor and conversion trends over time</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-6">
              {analytics?.monthlyStats?.map((month, index) => (
                <div key={index} className="space-y-2">
                  <div className="flex justify-between items-center">
                    <span className="font-medium text-slate-900">{month.month}</span>
                    <div className="flex space-x-4 text-sm">
                      <span className="text-blue-600">{month.visitors} visitors</span>
                      <span className="text-green-600">{month.conversions} conversions</span>
                    </div>
                  </div>
                  <div className="space-y-1">
                    <Progress 
                      value={(month.visitors / 1000) * 100} 
                      className="h-2"
                    />
                    <Progress 
                      value={(month.conversions / month.visitors) * 100} 
                      className="h-1"
                    />
                  </div>
                </div>
              )) || (
                <div className="text-center py-8">
                  <BarChart3 className="h-12 w-12 text-slate-300 mx-auto mb-4" />
                  <p className="text-slate-500">No monthly data available</p>
                </div>
              )}
            </div>
          </CardContent>
        </Card>

        {/* Action Items */}
        <Card className="mt-6">
          <CardHeader>
            <CardTitle className="flex items-center">
              <MousePointer className="h-5 w-5 mr-2 text-orange-600" />
              Optimization Suggestions
            </CardTitle>
            <CardDescription>Recommended actions to improve conversion</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <div className="p-4 bg-blue-50 rounded-lg border border-blue-100">
                <h4 className="font-semibold text-blue-900 mb-2">Improve Contact Form</h4>
                <p className="text-sm text-blue-700 mb-3">
                  Add more compelling call-to-action text to increase form submissions.
                </p>
                <Button size="sm" variant="outline" className="border-blue-200 text-blue-700">
                  Review Form
                </Button>
              </div>
              
              <div className="p-4 bg-green-50 rounded-lg border border-green-100">
                <h4 className="font-semibold text-green-900 mb-2">Follow Up Leads</h4>
                <p className="text-sm text-green-700 mb-3">
                  {analytics?.recentSubmissions?.filter(s => s.status === 'new').length || 0} new submissions need attention.
                </p>
                <Button size="sm" variant="outline" className="border-green-200 text-green-700">
                  View Leads
                </Button>
              </div>
              
              <div className="p-4 bg-purple-50 rounded-lg border border-purple-100">
                <h4 className="font-semibold text-purple-900 mb-2">Page Performance</h4>
                <p className="text-sm text-purple-700 mb-3">
                  Optimize high-traffic pages for better user experience.
                </p>
                <Button size="sm" variant="outline" className="border-purple-200 text-purple-700">
                  Optimize Pages
                </Button>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}